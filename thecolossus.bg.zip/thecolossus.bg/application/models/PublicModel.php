<?php

class PublicModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getOneLanguage($myLang)
    {
        $this->db->select('*');
        $this->db->where('abbr', $myLang);
        $result = $this->db->get('languages');
        return $result->row_array();
    }

    public function saveEmailToDb($post)
    {
        $post['time'] = time();
        $this->db->insert('received_emails', $post);
    }

    public function getValueStores()
    {
        $result = $this->db->get('value_store');
        return $result->result_array();
    }

    public function getOneValueStore($key)
    {
        $query = $this->db->query("SELECT value FROM value_store WHERE v_key = '$key'");
        $res = $query->row_array();
        return $res['value'];
    }

    public function checkFreeEmail($email)
    {
        $this->db->where('email', $email);
        $num = $this->db->count_all_results('users');
        if ($num > 0) {
            return lang('registered_by_user');
        }

        $this->db->where('email', $email);
        $num2 = $this->db->count_all_results('team_members');
        if ($num2 > 0) {
            return lang('registered_by_member');
        }
        return true;
    }

    public function registerUser($post)
    {
        $post['registered'] = time();
        $post['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
        unset($post['repeat_password'], $post['rules']);
        $post['password'] = md5($post['password']);
        $result = $this->db->insert('users', $post);
        return $result;
    }

    public function getLanguages()
    {
        $query = $this->db->query('SELECT abbr, name, flag FROM languages');
        return $query->result_array();
    }

    public function getComingEvents()
    {
        $this->db->order_by('date', 'asc');
        $this->db->where('date >', time());
        $this->db->where('events_translates.abbr', MY_LANGUAGE_ABBR);
        $this->db->join('events_translates', 'events.id = events_translates.for_id');
        $result = $this->db->get('events');
        return $result->result_array();
    }

    public function getFirstComingEvent()
    {
        $this->db->limit(1);
        $this->db->order_by('date', 'asc');
        $this->db->where('date >', time());
        $this->db->where('events_translates.abbr', MY_LANGUAGE_ABBR);
        $this->db->join('events_translates', 'events.id = events_translates.for_id');
        $result = $this->db->get('events');
        return $result->row_array();
    }

    public function getQuestions()
    {
        $this->db->order_by('position', 'asc');
        $this->db->where('abbr', MY_LANGUAGE_ABBR);
        $this->db->select('questions.id, questions.position, questions_translates.question, questions_translates.answer');
        $this->db->join('questions_translates', 'questions_translates.for_id = questions.id');
        $result = $this->db->get('questions');
        return $result->result_array();
    }

    public function getTexts()
    {
        $this->db->where('abbr', MY_LANGUAGE_ABBR);
        $this->db->join('texts_translates', 'texts_translates.for_id = texts.id');
        $result = $this->db->get('texts');
        return $result->result_array();
    }

    public function getUserInfoFromEmail($email)
    {
        $this->db->where('email', $email);
        $this->db->limit(1);
        $result = $this->db->get('users');
        return $result->row_array();
    }

    public function checkLogin($post)
    {
        $this->db->where('email', $post['email']);
        $this->db->where('password', md5($post['password']));
        $this->db->limit(1);
        $num_results = $this->db->count_all_results('users');
        if ($num_results > 0) {
            $this->db->where('email', $post['email']);
            $this->db->update('users', array('last_login' => time()));
        }
        return $num_results;
    }

    public function getMemberByHash($md5)
    {
        $this->db->where('hash', $md5);
        $result = $this->db->get('team_members');
        return $result->row_array();
    }

    public function verifyUser($post)
    {
        $this->db->where('hash', $post['hash']);
        $this->db->where('id', $post['user_id']);
        $this->db->update('team_members', array(
            'name' => $post['name'],
            'family' => $post['family'],
            'phone' => $post['phone'],
            'date_verified' => time(),
            'verified' => 1,
            'image' => $post['image']
        ));
    }

    public function getOneTeam($id)
    {
        $this->db->where('id', $id);
        $result = $this->db->get('teams');
        return $result->row_array();
    }

    public function getMembersForTeam($id)
    {
        $this->db->select('image, name, family');
        $this->db->where('for_team', $id);
        $this->db->where('verified', 1);
        $result = $this->db->get('team_members');
        return $result->result_array();
    }

    public function getUserForTeam($id)
    {
        $this->db->where('id', $id);
        $team_result = $this->db->get('teams');
        $team_result = $team_result->row_array();

        $this->db->select('image, name, family, "is_user"');
        $this->db->where('id', $team_result['for_user']);
        $result = $this->db->get('users');
        return $result->row_array();
    }

    public function setShare($team_id)
    {
        $this->db->where('id', $team_id);
        $this->db->set('shared', 'shared+1', false);
        $result = $this->db->update('teams');
        return $result;
    }

    public function getTeamsIds()
    {
        $this->db->select('id');
        $query = $this->db->get('teams');
        return $query->result();
    }

}
