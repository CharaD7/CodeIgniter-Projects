<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
  | -------------------------------------------------------------------------
  | URI ROUTING
  | -------------------------------------------------------------------------
  | This file lets you re-map URI requests to specific controller functions.
  |
  | Typically there is a one-to-one relationship between a URL string
  | and its corresponding controller class/method. The segments in a
  | URL normally follow this pattern:
  |
  |	example.com/class/method/id/
  |
  | In some instances, however, you may want to remap this relationship
  | so that a different class/function is called than the one
  | corresponding to the URL.
  |
  | Please see the user guide for complete details:
  |
  |	https://codeigniter.com/user_guide/general/routing.html
  |
  | -------------------------------------------------------------------------
  | RESERVED ROUTES
  | -------------------------------------------------------------------------
  |
  | There are three reserved routes:
  |
  |	$route['default_controller'] = 'welcome';
  |
  | This route indicates which controller class should be loaded if the
  | URI contains no data. In the above example, the "welcome" class
  | would be loaded.
  |
  |	$route['404_override'] = 'errors/page_missing';
  |
  | This route will tell the Router which controller/method to use if those
  | provided in the URL cannot be matched to a valid route.
  |
  |	$route['translate_uri_dashes'] = FALSE;
  |
  | This is not exactly a route, but allows you to automatically route
  | controller and method names that contain dashes. '-' isn't a valid
  | class or method name character, so it requires translation.
  | When you set this option to TRUE, it will replace ALL dashes in the
  | controller and method URI segments.
  |
  | Examples:	my-controller/index	-> my_controller/index
  |		my-controller/my-method	-> my_controller/my_method
 */

$exp = explode('.', $_SERVER['HTTP_HOST']);
if (count($exp) > 2 && strtolower($exp[0]) != 'www') {
    $route['default_controller'] = 'subdomain';
} else {
    $route['default_controller'] = 'home';
}
$route['translate_uri_dashes'] = FALSE;

$route['sitemap.xml'] = "home/sitemap";

$route['loadlanguage/(:any)'] = "Loader/jsFile/$1";
$route['verify/(:any)'] = "Verify/index/$1";
$route['(\w{2})/verify/(:any)'] = "Verify/index/$2";
$route['loadeventinfo'] = 'user/home/home/loadeventinfo';
$route['(\w{2})/loadeventinfo'] = 'user/home/home/loadeventinfo';
$route['fbshare/(:num)'] = 'subdomain/share/$1';

// ADMIN PANEL ROUTES
$route['admin'] = "admin/home/login";
$route['admin/logout'] = "admin/home/login/logout";
$route['admin/receivedemails'] = "admin/contactus/received";
$route['admin/sendemail'] = "admin/contactus/send";
$route['admin/sendedemails'] = "admin/contactus/sended";
$route['admin/settings'] = "admin/settings/settings";
$route['admin/administrators'] = "admin/administrators/administrators";
$route['admin/history'] = "admin/administrators/history";
$route['admin/history/(:num)'] = "admin/administrators/history/index/$1";
$route['admin/addevent'] = "admin/events/addevent";
$route['admin/events'] = "admin/events/events";
$route['admin/events/(:num)'] = "admin/events/events/index/$1";
$route['admin/languages'] = "admin/languages/languages";
$route['admin/questions'] = "admin/contactus/questions";
$route['admin/addquestion'] = "admin/contactus/addquestion";
$route['admin/texts'] = "admin/texts/texts";

// USERS ROUTES
$route['user'] = "user/home";
$route['(\w{2})/user'] = "user/home";
$route['user/myteam/(:num)'] = "user/myteam/myteam/index/$1";
$route['user/edit'] = "user/edit/edit";
$route['(\w{2})/user/edit'] = "user/edit/edit";
$route['(\w{2})/user/myteam/(:num)'] = "user/myteam/myteam/index/$2";
$route['user/logout'] = "user/home/home/logout";

$route['^(\w{2})$'] = $route['default_controller'];
$route['^(\w{2})/(:any)$'] = '$2';

$route['404_override'] = '';
