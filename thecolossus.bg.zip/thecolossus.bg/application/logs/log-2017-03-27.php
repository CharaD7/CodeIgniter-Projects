<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-27 08:49:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:49:21 --> 404 Page Not Found: /index
ERROR - 2017-03-27 08:49:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:49:21 --> 404 Page Not Found: /index
ERROR - 2017-03-27 08:49:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:49:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:50:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:50:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:50:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:54:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:54:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 08:56:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:12:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:14:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:19:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:30:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:36:13 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 09:36:13 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 09:36:13 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 09:36:13 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 09:39:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:39:57 --> Severity: Error --> Call to undefined function currencies() /var/www/html/thecolossus.bg/application/modules/admin/views/languages/index.php 175
ERROR - 2017-03-27 09:39:57 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:39:58 --> Severity: Error --> Call to undefined function currencies() /var/www/html/thecolossus.bg/application/modules/admin/views/languages/index.php 175
ERROR - 2017-03-27 09:39:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:39:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:40:46 --> Severity: Error --> Call to undefined function currencies() /var/www/html/thecolossus.bg/application/modules/admin/views/languages/index.php 175
ERROR - 2017-03-27 09:40:46 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:40:47 --> Severity: Error --> Call to undefined function currencies() /var/www/html/thecolossus.bg/application/modules/admin/views/languages/index.php 175
ERROR - 2017-03-27 09:40:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:41:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:41:21 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:48 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:41:48 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:42:38 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 09:42:38 --> Could not find the language line "upload_no_filepath"
ERROR - 2017-03-27 09:42:38 --> upload_no_filepath
ERROR - 2017-03-27 09:42:38 --> Language image upload error: <p>upload_no_filepath</p>
ERROR - 2017-03-27 09:42:38 --> Severity: Error --> Call to undefined function rcopy() /var/www/html/thecolossus.bg/application/modules/admin/controllers/languages/Languages.php 160
ERROR - 2017-03-27 09:43:02 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:43:15 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:27 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:29 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:29 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:36 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 09:43:36 --> Could not find the language line "upload_no_filepath"
ERROR - 2017-03-27 09:43:36 --> upload_no_filepath
ERROR - 2017-03-27 09:43:36 --> Language image upload error: <p>upload_no_filepath</p>
ERROR - 2017-03-27 09:43:37 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:46 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:43:56 --> Severity: Error --> Call to undefined function rreadDir() /var/www/html/thecolossus.bg/application/modules/admin/controllers/languages/Languages.php 130
ERROR - 2017-03-27 09:44:18 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:45:32 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:45:32 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:46:24 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:46:25 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:46:32 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:46:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:47:04 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:08 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:09 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:12 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:25 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:47:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:47:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:48:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:48:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:48:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:48:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:00 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:00 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:02 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:09 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:33 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:33 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:49:34 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:34 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:36 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:36 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:51 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:49:57 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:49:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:50:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:50:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:50:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:50:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:52:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:55:12 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:55:12 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:55:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:55:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:55:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 09:55:48 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:55:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:55:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:56:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:56:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 09:56:16 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:01:28 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:01:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:01:29 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:01:30 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:01:49 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:02 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:03 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:08 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:02:08 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:09 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:46 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:46 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:46 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:02:59 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:02:59 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:03:00 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:03:00 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:03:00 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:03:00 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:03:00 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:03:00 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:03:00 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:03:00 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:03:05 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:03:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:03:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:03:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:03:37 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:40 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:49 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:49 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:49 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:49 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:03:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Admin\LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:03:55 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:00 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:03 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:06 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:11 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:15 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:18 --> Severity: error --> Exception: Unable to locate the model you have specified: LanguagesModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-27 10:04:21 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:04:21 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 24
ERROR - 2017-03-27 10:04:22 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:04:22 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 24
ERROR - 2017-03-27 10:04:22 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:04:22 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 24
ERROR - 2017-03-27 10:04:48 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:04:48 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:04:49 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:04:49 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:04:49 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:04:49 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:05:43 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:05:43 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:05:44 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:05:44 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:05:45 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-27 10:05:45 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/core/MY_Controller.php 23
ERROR - 2017-03-27 10:05:52 --> Severity: Error --> Call to a member function result() on array /var/www/html/thecolossus.bg/application/core/MY_Controller.php 24
ERROR - 2017-03-27 10:05:59 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/core/MY_Controller.php 24
ERROR - 2017-03-27 10:05:59 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/core/MY_Controller.php 24
ERROR - 2017-03-27 10:08:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:11:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:16:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:17:23 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/core/MY_Controller.php 29
ERROR - 2017-03-27 10:17:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:17:31 --> Severity: Warning --> Illegal offset type in unset /var/www/html/thecolossus.bg/application/core/MY_Controller.php 26
ERROR - 2017-03-27 10:17:40 --> Severity: Warning --> Illegal offset type in unset /var/www/html/thecolossus.bg/application/core/MY_Controller.php 26
ERROR - 2017-03-27 10:17:44 --> Severity: Notice --> Undefined offset: 1 /var/www/html/thecolossus.bg/application/core/MY_Controller.php 26
ERROR - 2017-03-27 10:17:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:17:45 --> Severity: Notice --> Undefined offset: 1 /var/www/html/thecolossus.bg/application/core/MY_Controller.php 26
ERROR - 2017-03-27 10:17:49 --> Severity: Notice --> Undefined offset: 1 /var/www/html/thecolossus.bg/application/core/MY_Controller.php 26
ERROR - 2017-03-27 10:18:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:20:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:20:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:22:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:23:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:24:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:25:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:25:37 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:27:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:27:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:27:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:27:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:27:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:27:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:28:40 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:28:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:28:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:28:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:28:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:28:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:29:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:08 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:26 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:42 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:29:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:30:02 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:30:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:30:43 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:30:55 --> Severity: Error --> Call to undefined function uri_string() /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:22 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:23 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:23 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:23 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:23 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:23 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:23 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:23 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:23 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:24 --> Severity: Notice --> Use of undefined constant REQUEST_URI - assumed 'REQUEST_URI' /var/www/html/thecolossus.bg/application/config/routes.php 55
ERROR - 2017-03-27 10:31:24 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:42 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:31:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:31:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:31:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:32:00 --> 404 Page Not Found: /About-us/index
ERROR - 2017-03-27 10:32:00 --> 404 Page Not Found: /About-us/index
ERROR - 2017-03-27 10:32:27 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:32:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:32:32 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:32:34 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:34:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:34:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:34:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:34:43 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:34:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:35:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:35:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:35:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:35:48 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:35:52 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:36:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:36:09 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:36:38 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:36:38 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:36:52 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:37:08 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:02 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:03 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:38:12 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:12 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:12 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/thecolossus.bg/application/core/MY_Loader.php:6) /var/www/html/thecolossus.bg/system/core/Common.php 578
ERROR - 2017-03-27 10:38:22 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO), expecting function (T_FUNCTION) /var/www/html/thecolossus.bg/application/core/MY_Loader.php 6
ERROR - 2017-03-27 10:38:23 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:27 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:27 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:57 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:38:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:39:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:39:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:39:23 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:39:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:39:52 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:40:27 --> Severity: Notice --> Undefined property: MY_Router::$router /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:27 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:27 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:40:28 --> Severity: Notice --> Undefined property: MY_Router::$router /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:28 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:40:29 --> Severity: Notice --> Undefined property: MY_Router::$router /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:29 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:29 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:40:35 --> Severity: Parsing Error --> syntax error, unexpected end of file /var/www/html/thecolossus.bg/application/config/routes.php 76
ERROR - 2017-03-27 10:40:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:41:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:41:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:41:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:41:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:41:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:41:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:42:04 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:42:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:42:35 --> Severity: Notice --> Undefined property: CI_Exceptions::$router /var/www/html/thecolossus.bg/application/views/errors/html/error_404.php 2
ERROR - 2017-03-27 10:42:35 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/views/errors/html/error_404.php 2
ERROR - 2017-03-27 10:42:59 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:43:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:44:38 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:44:38 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:44:39 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:44:39 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 10:46:57 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:58 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:46:59 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:47:22 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:47:25 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:47:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:48:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:29 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:56:38 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:57:06 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:57:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:57:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:57:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 10:57:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:20 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:28 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:00:43 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:01:09 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:01:39 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:01:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:01:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:01:55 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:01:57 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:03:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:11:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:25:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:04 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:13 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:17 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:36 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:38 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:48 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:30:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:31:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:31:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:31:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:32:51 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:32:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:32:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:33:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:33:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:33:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:35:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:35:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:36:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:37:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:37:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:37:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:37:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:37:10 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:38:02 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:38:02 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:38:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:38:08 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:38:15 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:40:14 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:40:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:41:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:43:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:44:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:45:20 --> Severity: Notice --> Undefined variable: change_url /var/www/html/thecolossus.bg/application/views/parts/header.php 59
ERROR - 2017-03-27 11:45:21 --> Severity: Notice --> Undefined variable: change_url /var/www/html/thecolossus.bg/application/views/parts/header.php 59
ERROR - 2017-03-27 11:45:25 --> Severity: Notice --> Undefined variable: change_url /var/www/html/thecolossus.bg/application/views/parts/header.php 59
ERROR - 2017-03-27 11:45:30 --> Severity: Notice --> Undefined variable: change_url /var/www/html/thecolossus.bg/application/views/parts/header.php 59
ERROR - 2017-03-27 11:47:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:47:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:47:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:47:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:48:39 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:48:48 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:55 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:55 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:49:55 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:55 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:49:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:50:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:50:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:50:56 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:11 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:51:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:51:54 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:19 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:43 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:43 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:45 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:46 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:52:46 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:53:33 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:53:33 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:53:33 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:53:33 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:36 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:54:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:54:42 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:55:02 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 11:55:02 --> Could not find the language line "upload_no_filepath"
ERROR - 2017-03-27 11:55:02 --> upload_no_filepath
ERROR - 2017-03-27 11:55:02 --> Image Upload Error: <p>upload_no_filepath</p>
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> rmdir(application/language/english): Directory not empty /var/www/html/thecolossus.bg/application/helpers/rrmdir_helper.php 14
ERROR - 2017-03-27 11:55:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/thecolossus.bg/system/core/Exceptions.php:271) /var/www/html/thecolossus.bg/system/helpers/url_helper.php 564
ERROR - 2017-03-27 11:55:37 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:55:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:55:37 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:55:40 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:55:40 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:55:40 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:18 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:31 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:56:41 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 11:56:41 --> Could not find the language line "upload_no_filepath"
ERROR - 2017-03-27 11:56:41 --> upload_no_filepath
ERROR - 2017-03-27 11:56:41 --> Image Upload Error: <p>upload_no_filepath</p>
ERROR - 2017-03-27 11:56:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:56:41 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:58:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:49 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:52 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:58:52 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:05 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:15 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:15 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 11:59:35 --> 404 Page Not Found: /index
ERROR - 2017-03-27 11:59:37 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:00 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:00 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:00 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:00 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:01 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:01 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:01 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:01 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:00:07 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:01:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 12:01:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 12:40:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 12:43:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 12:45:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:45:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:45:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:45:44 --> 404 Page Not Found: /index
ERROR - 2017-03-27 12:45:56 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 12:45:56 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 12:45:56 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 12:45:56 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 12:46:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 12:51:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 13:14:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 13:15:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 13:38:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:38:50 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:52:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:52:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 13:55:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 13:56:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 13:59:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:01:05 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 25
ERROR - 2017-03-27 14:01:05 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 25
ERROR - 2017-03-27 14:01:09 --> Severity: Parsing Error --> syntax error, unexpected '<' /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 39
ERROR - 2017-03-27 14:01:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:01:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 14:01:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 14:01:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 14:01:47 --> 404 Page Not Found: /index
ERROR - 2017-03-27 14:02:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:02:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:02:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:16:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:19:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:25:57 --> Severity: Notice --> Undefined index: abbr /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:25:57 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:26:45 --> Severity: Notice --> Undefined index: abbr /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:02 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 14:28:02 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 14:28:02 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 14:28:02 --> Severity: Notice --> Undefined index: abbr /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:21 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 14:28:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 14:28:21 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 14:28:21 --> Severity: Notice --> Undefined index: abbr /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:22 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 14:28:22 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 14:28:22 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 14:28:22 --> Severity: Notice --> Undefined index: abbr /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:22 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 25
ERROR - 2017-03-27 14:28:28 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 14:28:28 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 14:28:28 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 14:41:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:41:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:42:48 --> Severity: Parsing Error --> syntax error, unexpected ''' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 20
ERROR - 2017-03-27 14:42:49 --> Severity: Parsing Error --> syntax error, unexpected ''' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 20
ERROR - 2017-03-27 14:42:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:46:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 14:56:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:02:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:02:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:02:47 --> 404 Page Not Found: Events/1
ERROR - 2017-03-27 15:02:53 --> 404 Page Not Found: /index
ERROR - 2017-03-27 15:03:02 --> Severity: Notice --> Undefined variable: query /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:03:02 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php:65) /var/www/html/thecolossus.bg/system/core/Common.php 578
ERROR - 2017-03-27 15:03:02 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:03:03 --> Severity: Notice --> Undefined variable: query /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:03:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php:65) /var/www/html/thecolossus.bg/system/core/Common.php 578
ERROR - 2017-03-27 15:03:03 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:03:12 --> Severity: Notice --> Undefined variable: query /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:03:12 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:10:03 --> Severity: Notice --> Undefined variable: query /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:10:03 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:10:36 --> Severity: Notice --> Undefined variable: query /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:10:36 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 65
ERROR - 2017-03-27 15:15:32 --> Severity: Notice --> Undefined variable: query /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 64
ERROR - 2017-03-27 15:15:32 --> Severity: Error --> Call to a member function result_array() on null /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 64
ERROR - 2017-03-27 15:18:39 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:19:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:19:43 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2017-03-27 15:19:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:20:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:20:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:20:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:20:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:20:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:32:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:32:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:32:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:32:52 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:11 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:33:11 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:11 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:33:11 --> Severity: Warning --> Attempt to modify property of non-object /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:29 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:33:29 --> Severity: Warning --> Illegal string offset 'description' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:29 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:33:29 --> Severity: Warning --> Illegal string offset 'description' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:33:44 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:33:44 --> Severity: Warning --> Illegal string offset 'description' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:44 --> Severity: Warning --> Illegal string offset 'title' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 66
ERROR - 2017-03-27 15:33:44 --> Severity: Warning --> Illegal string offset 'description' /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 67
ERROR - 2017-03-27 15:33:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:39:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:40:45 --> Severity: Parsing Error --> syntax error, unexpected ')' /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 29
ERROR - 2017-03-27 15:57:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 15:59:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:01:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:01:58 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:01:58 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:01:58 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:01:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:02:06 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:02:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:02:06 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:02:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:25:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:25:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:26:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:26:44 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:26:44 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:26:44 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:26:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:28:10 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:28:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:28:10 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:28:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:28:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:29:29 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:29:29 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:29:29 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:29:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:29:31 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:29:31 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:29:31 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:30:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:30:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:30:59 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:30:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:30:59 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:31:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:31:47 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:31:47 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:31:47 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:31:51 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:31:51 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:31:51 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:32:29 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:32:29 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:32:29 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:32:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:32:29 --> 404 Page Not Found: /index
ERROR - 2017-03-27 16:32:29 --> 404 Page Not Found: /index
ERROR - 2017-03-27 16:32:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 16:32:30 --> 404 Page Not Found: /index
ERROR - 2017-03-27 16:33:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:33:14 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-27 16:33:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-27 16:33:14 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-27 16:35:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:36:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:36:56 --> Severity: Notice --> Undefined index: image /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 37
ERROR - 2017-03-27 16:36:58 --> Severity: Notice --> Undefined index: image /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 37
ERROR - 2017-03-27 16:37:14 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 37
ERROR - 2017-03-27 16:37:15 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/thecolossus.bg/application/modules/admin/views/events/addevent.php 37
ERROR - 2017-03-27 16:43:51 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 77
ERROR - 2017-03-27 16:43:51 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 81
ERROR - 2017-03-27 16:43:51 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 77
ERROR - 2017-03-27 16:43:51 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 81
ERROR - 2017-03-27 16:43:52 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 77
ERROR - 2017-03-27 16:43:52 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 81
ERROR - 2017-03-27 16:44:54 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 77
ERROR - 2017-03-27 16:44:54 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 81
ERROR - 2017-03-27 16:44:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:47:09 --> Severity: Warning --> Missing argument 1 for EventsModel::getEvents(), called in /var/www/html/thecolossus.bg/application/modules/admin/controllers/events/Events.php on line 25 and defined /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 73
ERROR - 2017-03-27 16:47:09 --> Severity: Warning --> Missing argument 2 for EventsModel::getEvents(), called in /var/www/html/thecolossus.bg/application/modules/admin/controllers/events/Events.php on line 25 and defined /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 73
ERROR - 2017-03-27 16:47:09 --> Severity: Notice --> Undefined variable: limit /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 79
ERROR - 2017-03-27 16:47:09 --> Severity: Notice --> Undefined variable: page /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 79
ERROR - 2017-03-27 16:47:09 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `id` DESC
ERROR - 2017-03-27 16:47:09 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-27 16:47:09 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-27 16:47:10 --> Severity: Warning --> Missing argument 1 for EventsModel::getEvents(), called in /var/www/html/thecolossus.bg/application/modules/admin/controllers/events/Events.php on line 25 and defined /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 73
ERROR - 2017-03-27 16:47:10 --> Severity: Warning --> Missing argument 2 for EventsModel::getEvents(), called in /var/www/html/thecolossus.bg/application/modules/admin/controllers/events/Events.php on line 25 and defined /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 73
ERROR - 2017-03-27 16:47:10 --> Severity: Notice --> Undefined variable: limit /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 79
ERROR - 2017-03-27 16:47:10 --> Severity: Notice --> Undefined variable: page /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 79
ERROR - 2017-03-27 16:47:10 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `id` DESC
ERROR - 2017-03-27 16:47:10 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-27 16:47:10 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-27 16:47:24 --> Severity: Warning --> Missing argument 1 for EventsModel::getEvents(), called in /var/www/html/thecolossus.bg/application/modules/admin/controllers/events/Events.php on line 25 and defined /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 73
ERROR - 2017-03-27 16:47:24 --> Severity: Warning --> Missing argument 2 for EventsModel::getEvents(), called in /var/www/html/thecolossus.bg/application/modules/admin/controllers/events/Events.php on line 25 and defined /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 73
ERROR - 2017-03-27 16:47:24 --> Severity: Notice --> Undefined variable: limit /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 79
ERROR - 2017-03-27 16:47:24 --> Severity: Notice --> Undefined variable: page /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 79
ERROR - 2017-03-27 16:47:24 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `id` DESC
ERROR - 2017-03-27 16:47:24 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-27 16:47:24 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-27 16:48:28 --> Query error: Column 'id' in order clause is ambiguous - Invalid query: SELECT *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `id` DESC
 LIMIT 20
ERROR - 2017-03-27 16:48:28 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-27 16:48:28 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-27 16:50:18 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:50:18 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:50:18 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:50:18 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:51:06 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:51:06 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:51:06 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:51:06 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:52:07 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:52:07 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:52:07 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:52:07 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:52:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:52:08 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:52:08 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:52:08 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:52:08 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:52:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 16:52:10 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:52:10 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:52:10 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:52:10 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:53:19 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:53:19 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:53:19 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:53:19 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:53:47 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:53:47 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:53:47 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:53:47 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:54:17 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:54:17 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:54:17 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:54:17 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:54:50 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:54:50 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:54:50 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:54:50 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:56:57 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:56:57 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:56:57 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:56:57 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:57:02 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:57:02 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:57:02 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:57:02 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:57:36 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:57:36 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:57:36 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:57:36 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 16:57:41 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 16:57:41 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 16:57:41 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 16:57:41 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:12:43 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:12:43 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:12:43 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:12:43 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:12:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:21:29 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:21:29 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:21:29 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:21:29 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:22:09 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:22:09 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:22:09 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:22:09 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:22:16 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:22:16 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:22:16 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:22:16 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:22:19 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:22:19 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:22:19 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:22:19 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:22:32 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:22:32 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:22:32 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:22:32 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:22:36 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:22:36 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:22:36 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:22:36 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:22:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:22:40 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:22:40 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:22:40 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:22:40 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:23:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:23:30 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:23:30 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:23:30 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:23:30 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:23:38 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:23:38 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:23:38 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:23:38 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:23:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:24:01 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:24:01 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:24:01 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:24:01 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:24:46 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:24:46 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:24:46 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:24:46 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:25:12 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:25:12 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:25:12 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:25:12 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:25:44 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:25:44 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:25:44 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:25:44 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:26:22 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:26:22 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:26:22 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:26:22 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:26:29 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:26:29 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:26:29 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:26:29 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:26:30 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:26:30 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:26:30 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:26:30 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:26:46 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:26:46 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:26:46 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:26:46 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:26:56 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:26:56 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:26:56 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:26:56 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:27:02 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:27:02 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:27:02 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:27:02 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:27:44 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:27:44 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:27:44 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:27:44 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:28:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:28:34 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:28:34 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:28:34 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:28:34 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:28:45 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:28:45 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:28:45 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:28:45 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:28:50 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:29:35 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:29:35 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:29:35 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:29:35 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:29:36 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:29:36 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:29:36 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:29:36 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:29:38 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:29:38 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:29:38 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:29:38 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:29:45 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:29:45 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:29:45 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:29:45 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:29:59 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:29:59 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:29:59 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:29:59 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:30:24 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:30:24 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:30:24 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:30:24 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:31:30 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:31:30 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:31:30 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:31:30 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:31:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:31:38 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:31:38 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:31:38 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:31:38 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:33:24 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:33:24 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:33:24 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:33:24 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:33:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:33:40 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:33:40 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:33:40 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:33:40 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:33:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-27 17:33:53 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:33:53 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:33:53 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:33:53 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:35:09 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:35:09 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:35:09 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:35:09 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:35:33 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:35:33 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:35:33 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:35:33 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:35:48 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:35:48 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:35:48 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:35:48 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:35:59 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:35:59 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:35:59 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:35:59 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:36:06 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:36:06 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:36:06 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:36:06 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:43:13 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-27 17:43:13 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-27 17:43:13 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-27 17:43:13 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-27 17:43:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
