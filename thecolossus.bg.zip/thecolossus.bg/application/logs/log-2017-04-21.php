<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-21 11:58:20 --> 404 Page Not Found: /index
