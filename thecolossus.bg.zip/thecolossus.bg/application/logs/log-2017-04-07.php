<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-07 09:29:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:29:38 --> 404 Page Not Found: /index
ERROR - 2017-04-07 09:29:38 --> 404 Page Not Found: /index
ERROR - 2017-04-07 09:29:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:29:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 09:29:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 09:29:59 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 09:29:59 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 09:29:59 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 09:29:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 09:29:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 09:30:02 --> Severity: Notice --> Undefined variable: title /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 10
ERROR - 2017-04-07 09:32:25 --> Severity: Notice --> Undefined variable: title /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 10
ERROR - 2017-04-07 09:32:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:32:39 --> Severity: Notice --> Undefined variable: title /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 10
ERROR - 2017-04-07 09:32:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:32:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:32:58 --> Severity: Notice --> Undefined variable: title /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 10
ERROR - 2017-04-07 09:32:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:32:59 --> Severity: Notice --> Undefined variable: title /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 10
ERROR - 2017-04-07 09:32:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:33:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:41:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:41:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:42:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:43:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:43:41 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 09:43:41 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 09:43:45 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 09:43:45 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 09:43:45 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 09:43:45 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 09:43:45 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 09:43:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:43:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:45:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:45:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:50:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:50:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:55:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:55:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:56:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:56:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:58:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:58:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 09:59:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:00:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:07:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:07:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:07:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:07:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:14:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:21:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:24:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:10 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:25:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:25:10 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:25:10 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-07 10:25:10 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-07 10:25:10 --> Could not find the language line "db_must_use_set"
ERROR - 2017-04-07 10:25:31 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:25:31 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:25:31 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:25:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:40 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:25:40 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:25:40 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:25:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:46 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:25:46 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:25:46 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:25:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:25:51 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:25:51 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:25:51 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:26:10 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:26:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:26:10 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:26:23 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:26:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:26:23 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:26:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:27:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:27:58 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/thecolossus.bg/application/modules/user/views/edit/index.php 50
ERROR - 2017-04-07 10:27:59 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/thecolossus.bg/application/modules/user/views/edit/index.php 50
ERROR - 2017-04-07 10:28:05 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:28:05 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:28:05 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:28:58 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 10:28:58 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 10:30:03 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 10:30:03 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 10:30:03 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 10:31:02 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 10:31:02 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 10:31:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:31:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:32:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:32:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:32:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:32:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:38:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:38:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:40:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:41:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:41:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:41:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:41:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:44:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:51:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:52:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:53:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:55:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:55:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:56:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:56:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 10:57:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:01:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:06:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:06:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:06:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:07:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:07:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:07:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:07:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:12:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:12:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:18:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:19:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:19:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:19:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:19:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:20:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:20:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:20:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:26:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:26:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:27:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:29:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:32:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:32:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:32:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:32:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:33:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:35:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:35:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:36:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:37:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:39:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:39:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:40:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:42:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:42:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:42:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:43:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:50:55 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 11:50:55 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 11:50:58 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 11:50:58 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 11:50:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:54:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:54:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:55:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:55:27 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 11:55:27 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 11:55:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 11:55:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 11:56:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:56:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:59:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 11:59:09 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 11:59:09 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 11:59:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:00:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:00:48 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:00:48 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:02:09 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:02:09 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:03:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:03:04 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:03:04 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:03:06 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 12:03:06 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 12:03:06 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 12:03:06 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:03:06 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:03:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:03:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:04:02 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:04:02 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:04:04 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 12:04:04 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 12:04:04 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 12:04:04 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:04:04 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:05:47 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:05:47 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:05:49 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 12:05:49 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 12:05:49 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 12:05:49 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:05:49 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:05:52 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 12:05:52 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 12:05:52 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 12:06:14 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:06:14 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:07:48 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:07:48 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:07:50 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 12:07:50 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 12:07:50 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 12:08:05 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:08:05 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:08:47 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:08:47 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:09:51 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:09:51 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:13:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:13:16 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:13:16 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:13:57 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:13:57 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:14:00 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:14:00 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:14:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:14:01 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:14:01 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:14:41 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:14:41 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:14:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:14:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:14:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:15:15 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:15:15 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:15:36 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:15:36 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:15:45 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:15:45 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:15:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:15:49 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:15:49 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:15:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:15:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:15:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:15:56 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:16:19 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:16:19 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:16:26 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:16:26 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:16:30 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:16:30 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:19:50 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:19:50 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:19:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:19:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:19:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:20:01 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:20:01 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:20:15 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 140
ERROR - 2017-04-07 12:20:15 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 170
ERROR - 2017-04-07 12:20:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:20:18 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 12:20:18 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 12:20:18 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 12:22:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:24:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:24:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:28:36 --> Severity: Error --> Call to undefined function recode_string() /var/www/html/thecolossus.bg/application/modules/user/views/home/index.php 4
ERROR - 2017-04-07 12:28:37 --> Severity: Error --> Call to undefined function recode_string() /var/www/html/thecolossus.bg/application/modules/user/views/home/index.php 4
ERROR - 2017-04-07 12:33:39 --> Severity: Parsing Error --> syntax error, unexpected '?>' /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 89
ERROR - 2017-04-07 12:33:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:34:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:34:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:36:37 --> 404 Page Not Found: /index
ERROR - 2017-04-07 12:36:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:37:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:39:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:40:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:41:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:41:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:42:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:43:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:43:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:46:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:46:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:47:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:48:26 --> Severity: Notice --> Undefined index: default_controller /var/www/html/thecolossus.bg/application/config/routes.php 94
ERROR - 2017-04-07 12:48:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:48:27 --> Severity: Notice --> Undefined index: default_controller /var/www/html/thecolossus.bg/application/config/routes.php 94
ERROR - 2017-04-07 12:48:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:49:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:50:16 --> 404 Page Not Found: /index
ERROR - 2017-04-07 12:51:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:51:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:52:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:52:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:54:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:55:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:55:30 --> 404 Page Not Found: /index
ERROR - 2017-04-07 12:55:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 12:56:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 14:40:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 14:40:00 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:40:00 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:40:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 14:40:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 14:41:58 --> 404 Page Not Found: Subdomain/team-3
ERROR - 2017-04-07 14:42:07 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:07 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:08 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:15 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:15 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:16 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:16 --> 404 Page Not Found: /index
ERROR - 2017-04-07 14:42:42 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:43 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:46 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:46 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:47 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:48 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:49 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:49 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:50 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:50 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:42:50 --> Severity: Warning --> Missing argument 1 for Subdomain::index() /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 13
ERROR - 2017-04-07 14:56:45 --> Severity: Notice --> Undefined variable: my_lang_flag /var/www/html/thecolossus.bg/application/views/parts/header.php 48
ERROR - 2017-04-07 14:56:45 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/views/parts/header.php 52
ERROR - 2017-04-07 14:56:45 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/views/parts/header.php 52
ERROR - 2017-04-07 14:56:45 --> Severity: Notice --> Undefined variable: view /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 26
ERROR - 2017-04-07 14:56:45 --> Severity: Notice --> Undefined variable: _ci_file /var/www/html/thecolossus.bg/application/third_party/MX/Loader.php 340
ERROR - 2017-04-07 14:56:46 --> Severity: Notice --> Undefined variable: my_lang_flag /var/www/html/thecolossus.bg/application/views/parts/header.php 48
ERROR - 2017-04-07 14:56:46 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/views/parts/header.php 52
ERROR - 2017-04-07 14:56:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/views/parts/header.php 52
ERROR - 2017-04-07 14:56:46 --> Severity: Notice --> Undefined variable: view /var/www/html/thecolossus.bg/application/controllers/Subdomain.php 26
ERROR - 2017-04-07 14:56:46 --> Severity: Notice --> Undefined variable: _ci_file /var/www/html/thecolossus.bg/application/third_party/MX/Loader.php 340
ERROR - 2017-04-07 15:04:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:04:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:04:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:04:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:06:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:06:36 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 15:06:36 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 15:06:36 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 15:06:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:06:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:07:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:08:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:10:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:10:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:10:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:10:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:10:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:10:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:11:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:11:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:11:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:13:15 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/views/subdomain/index.php 12
ERROR - 2017-04-07 15:13:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:13:16 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/views/subdomain/index.php 12
ERROR - 2017-04-07 15:13:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:14:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:14:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:14:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:14:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:15:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:15:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:15:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:15:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:15:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:15:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:16:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:16:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:16:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:18:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:19:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:19:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:20:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:20:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:20:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:20:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:21:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:21:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:22:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:22:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:22:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:23:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:23:17 --> 404 Page Not Found: /index
ERROR - 2017-04-07 15:23:18 --> 404 Page Not Found: /index
ERROR - 2017-04-07 15:23:22 --> 404 Page Not Found: /index
ERROR - 2017-04-07 15:23:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:23:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:24:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:25:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:25:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:25:30 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-07 15:25:30 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-07 15:25:30 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-07 15:25:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:25:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:25:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:25:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:27:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:27:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:27:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:27:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:27:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:28:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:29:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:29:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:30:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:30:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:30:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:30:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:31:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:31:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:32:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:34:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:34:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:35:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:35:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:43:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:43:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:44:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:44:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:45:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:45:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:49:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:54:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:55:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:55:15 --> Could not find the language line "members"
ERROR - 2017-04-07 15:55:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:55:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:55:16 --> Could not find the language line "members"
ERROR - 2017-04-07 15:56:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:56:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:56:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:58:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:58:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:58:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:58:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:58:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 15:58:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:00:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:01:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:03:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:05:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:06:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:08:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:09:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:09:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:09:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:10:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:10:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:12:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:12:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:13:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:13:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:13:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:13:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:13:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:13:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:14:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:15:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:15:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:15:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:15:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:18:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:19:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:20:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:20:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:20:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:21:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:21:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:21:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:21:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:22:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:27:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:27:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:27:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:27:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:28:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:28:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:29:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:30:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:30:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:33:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:33:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:33:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:36:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:36:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:37:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:38:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:39:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:42:56 --> Severity: Error --> Call to undefined function row_array() /var/www/html/thecolossus.bg/application/models/PublicModel.php 170
ERROR - 2017-04-07 16:42:57 --> Severity: Error --> Call to undefined function row_array() /var/www/html/thecolossus.bg/application/models/PublicModel.php 170
ERROR - 2017-04-07 16:43:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:46:06 --> Query error: Unknown column 'is_user' in 'field list' - Invalid query: SELECT `image`, `name`, `family`, `is_user`
FROM `users`
WHERE `id` = '1'
ERROR - 2017-04-07 16:46:06 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-07 16:46:06 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-07 16:46:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:46:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '1
FROM `users`
WHERE `id` = '1'' at line 1 - Invalid query: SELECT `image`, `name`, `family`, `is_user =` 1
FROM `users`
WHERE `id` = '1'
ERROR - 2017-04-07 16:46:09 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-07 16:46:09 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-07 16:46:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:46:22 --> Query error: Unknown column 'is_user =' in 'field list' - Invalid query: SELECT `image`, `name`, `family`, `is_user =` "1"
FROM `users`
WHERE `id` = '1'
ERROR - 2017-04-07 16:46:22 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-07 16:46:22 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-07 16:46:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:47:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:47:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 16:48:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:36:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:36:49 --> 404 Page Not Found: /index
ERROR - 2017-04-07 17:36:49 --> 404 Page Not Found: /index
ERROR - 2017-04-07 17:36:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:36:57 --> 404 Page Not Found: /index
ERROR - 2017-04-07 17:36:57 --> 404 Page Not Found: /index
ERROR - 2017-04-07 17:47:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:50:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:52:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:53:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:53:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:55:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-07 17:56:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
