<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-04 10:55:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 10:55:09 --> 404 Page Not Found: /index
ERROR - 2017-04-04 10:55:10 --> 404 Page Not Found: /index
ERROR - 2017-04-04 11:33:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 11:33:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 11:43:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 11:47:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 11:55:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:03:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:05:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:12:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:12:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:15:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:19:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:21:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:21:48 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:21:49 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:21:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:22:05 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:22:46 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:22:53 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:23:12 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:24:33 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:24:48 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:27:33 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:27:34 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:31:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:32:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:32:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:39:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:39:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:40:22 --> 404 Page Not Found: /index
ERROR - 2017-04-04 12:40:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:40:55 --> 404 Page Not Found: /index
ERROR - 2017-04-04 12:40:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:41:48 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:41:49 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:42:00 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:42:01 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 12:42:15 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:42:43 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:42:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:42:44 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:42:56 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:43:02 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:43:26 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:43:27 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:43:50 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:44:08 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:44:23 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:45:29 --> 404 Page Not Found: /index
ERROR - 2017-04-04 12:45:31 --> 404 Page Not Found: /index
ERROR - 2017-04-04 12:45:36 --> 404 Page Not Found: /index
ERROR - 2017-04-04 12:50:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 12:52:35 --> 404 Page Not Found: ../modules/user/controllers/createteam//index
ERROR - 2017-04-04 12:59:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 13:56:48 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-04 14:07:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:10:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:23:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:25:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:29:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:30:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:31:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:32:36 --> Severity: error --> Exception: /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php exists, but doesn't declare class UsersModel /var/www/html/thecolossus.bg/system/core/Loader.php 336
ERROR - 2017-04-04 14:32:36 --> Severity: error --> Exception: /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php exists, but doesn't declare class UsersModel /var/www/html/thecolossus.bg/system/core/Loader.php 336
ERROR - 2017-04-04 14:32:47 --> Severity: 4096 --> Object of class Myteam could not be converted to string /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:47 --> Severity: Notice --> Object of class Myteam to string conversion /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:47 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Object /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php:25) /var/www/html/thecolossus.bg/system/core/Common.php 578
ERROR - 2017-04-04 14:32:47 --> Severity: Error --> Call to a member function render() on null /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:52 --> Severity: 4096 --> Object of class Myteam could not be converted to string /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:52 --> Severity: Notice --> Object of class Myteam to string conversion /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:52 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$Object /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:32:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php:25) /var/www/html/thecolossus.bg/system/core/Common.php 578
ERROR - 2017-04-04 14:32:52 --> Severity: Error --> Call to a member function render() on null /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 25
ERROR - 2017-04-04 14:40:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:46:54 --> Severity: Error --> Call to undefined method Myteam::uploadImage() /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 33
ERROR - 2017-04-04 14:47:05 --> Severity: Error --> Using $this when not in object context /var/www/html/thecolossus.bg/application/helpers/uploader_helper.php 11
ERROR - 2017-04-04 14:47:29 --> Severity: Error --> Using $this when not in object context /var/www/html/thecolossus.bg/application/helpers/uploader_helper.php 12
ERROR - 2017-04-04 14:47:30 --> Severity: Error --> Using $this when not in object context /var/www/html/thecolossus.bg/application/helpers/uploader_helper.php 12
ERROR - 2017-04-04 14:47:37 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 14:47:37 --> Could not find the language line "upload_not_writable"
ERROR - 2017-04-04 14:47:37 --> upload_not_writable
ERROR - 2017-04-04 14:47:37 --> Image Upload Error: <p>upload_not_writable</p>
ERROR - 2017-04-04 14:47:37 --> Severity: Notice --> Undefined index: c_img /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 35
ERROR - 2017-04-04 14:47:52 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 14:47:52 --> Could not find the language line "upload_not_writable"
ERROR - 2017-04-04 14:47:52 --> upload_not_writable
ERROR - 2017-04-04 14:47:52 --> Image Upload Error: <p>upload_not_writable</p>
ERROR - 2017-04-04 14:47:55 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 14:47:55 --> Could not find the language line "upload_not_writable"
ERROR - 2017-04-04 14:47:55 --> upload_not_writable
ERROR - 2017-04-04 14:47:55 --> Image Upload Error: <p>upload_not_writable</p>
ERROR - 2017-04-04 14:56:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 14:59:42 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 14:59:42 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 14:59:42 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 14:59:45 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 14:59:45 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 14:59:45 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 15:15:32 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 15:15:32 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 15:15:32 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 15:15:35 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 15:15:35 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 15:15:35 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 15:26:45 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 15:26:45 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 15:26:45 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 15:27:33 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 15:27:33 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 15:27:33 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 15:28:10 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-04 15:28:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-04 15:28:10 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-04 15:31:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:34:05 --> Severity: Warning --> Missing argument 1 for UsersModel::addTeam(), called in /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php on line 46 and defined /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 17
ERROR - 2017-04-04 15:34:05 --> Severity: Notice --> Undefined variable: post /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 20
ERROR - 2017-04-04 15:34:05 --> Severity: Notice --> Undefined variable: post /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 21
ERROR - 2017-04-04 15:34:05 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `teams` (`name`, `image`, `time_created`, `for_user`) VALUES (NULL, NULL, 1491309245, '1')
ERROR - 2017-04-04 15:34:05 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-04 15:34:05 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-04 15:36:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:43:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:46:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:49:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:54:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:54:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 15:57:21 --> Could not find the language line "team_team"
ERROR - 2017-04-04 16:10:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 16:27:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 16:30:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 16:39:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 16:44:21 --> Severity: Notice --> Undefined variable: myTeamText /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 40
ERROR - 2017-04-04 16:44:22 --> Severity: Notice --> Undefined variable: myTeamText /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 40
ERROR - 2017-04-04 16:46:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 16:47:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 16:52:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 17:09:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 17:13:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-04 17:40:51 --> 404 Page Not Found: /index
