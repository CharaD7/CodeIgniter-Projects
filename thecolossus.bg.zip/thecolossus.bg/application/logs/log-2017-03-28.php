<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-28 09:54:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 09:54:04 --> 404 Page Not Found: /index
ERROR - 2017-03-28 09:54:04 --> 404 Page Not Found: /index
ERROR - 2017-03-28 10:03:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:06:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:12:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:18:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:20:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:20:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:22:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:25:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:27:36 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:27:36 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:27:36 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:27:36 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:27:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:38:46 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:38:46 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:38:46 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:38:46 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:38:51 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-28 10:38:51 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-28 10:38:51 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-28 10:38:51 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:38:51 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:38:51 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:38:51 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:38:54 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:38:54 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:38:54 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:38:54 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:40:08 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:40:08 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:40:08 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:40:08 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:40:51 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:40:51 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:40:51 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:40:51 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:40:52 --> Severity: Notice --> Undefined index: destionation /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 72
ERROR - 2017-03-28 10:40:52 --> Severity: Notice --> Undefined index: destionation /var/www/html/thecolossus.bg/application/modules/admin/models/EventsModel.php 72
ERROR - 2017-03-28 10:40:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 10:41:12 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-28 10:41:12 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-28 10:41:12 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-28 10:41:12 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 10:41:12 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 10:41:12 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 10:41:12 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 10:41:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:02:23 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-03-28 11:02:23 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-03-28 11:02:23 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-03-28 11:02:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:02:23 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:02:23 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:02:23 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:02:23 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:10:16 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:10:16 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:10:16 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:10:16 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:10:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:20:53 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:20:53 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:20:53 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:20:53 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:20:58 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:20:58 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:20:58 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:20:58 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:21:05 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:21:05 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:21:05 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:21:05 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:21:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:22:41 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:22:41 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:22:41 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:22:41 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:34:47 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:34:47 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:34:47 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:34:47 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:34:51 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:34:51 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:34:51 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:34:51 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:37:25 --> Severity: Notice --> Undefined index: image1 /var/www/html/thecolossus.bg/application/views/events/index.php 19
ERROR - 2017-03-28 11:37:26 --> Severity: Notice --> Undefined index: image1 /var/www/html/thecolossus.bg/application/views/events/index.php 19
ERROR - 2017-03-28 11:37:28 --> Severity: Notice --> Undefined index: image1 /var/www/html/thecolossus.bg/application/views/events/index.php 19
ERROR - 2017-03-28 11:37:28 --> Severity: Notice --> Undefined index: image1 /var/www/html/thecolossus.bg/application/views/events/index.php 19
ERROR - 2017-03-28 11:37:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:37:51 --> Severity: Notice --> Undefined index: title /var/www/html/thecolossus.bg/application/views/events/index.php 24
ERROR - 2017-03-28 11:37:52 --> Severity: Notice --> Undefined index: title /var/www/html/thecolossus.bg/application/views/events/index.php 24
ERROR - 2017-03-28 11:37:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:39:01 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:39:01 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:39:01 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:39:01 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:40:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:40:17 --> 404 Page Not Found: /index
ERROR - 2017-03-28 11:40:19 --> 404 Page Not Found: /index
ERROR - 2017-03-28 11:41:23 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:41:23 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:41:23 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:41:23 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:41:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:42:00 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:42:00 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:42:00 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:42:00 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:42:24 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:42:24 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:42:24 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:42:24 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:43:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:44:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:56:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 11:56:44 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:56:44 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:56:44 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:56:44 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:56:55 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 11:56:55 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 11:56:55 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 11:56:55 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 11:59:05 --> 404 Page Not Found: /index
ERROR - 2017-03-28 12:00:45 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:00:45 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:00:45 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:00:45 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:12:14 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:12:14 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:12:14 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:12:14 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:14:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:14:18 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:14:18 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:14:18 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:14:18 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:18:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:22:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:22:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:22:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:23:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:23:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:25:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:30:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:32:54 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:32:54 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:32:54 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:32:54 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:36:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:36:51 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:36:51 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:36:51 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:36:51 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:36:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:37:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:37:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:37:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:37:30 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:37:30 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:37:30 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:37:30 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:38:03 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:38:03 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:38:03 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:38:03 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:38:09 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:38:09 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:38:09 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:38:09 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:38:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:38:56 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:38:56 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:38:56 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:38:56 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:39:11 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:39:11 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:39:11 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:39:11 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:39:13 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:39:13 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:39:13 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:39:13 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:43:19 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:43:19 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:43:19 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:43:19 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:43:20 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:43:20 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:43:20 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:43:20 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:43:21 --> Query error: Unknown column 'events_translates.title' in 'field list' - Invalid query: SELECT `events`.`id`, `events`.`date`, `events`.`image`, `events`.`google`, `events_translates`.`title`, `events_translates`.`description`, `events_translates`.`destination`
FROM `events`
WHERE `id` = '3'
ERROR - 2017-03-28 12:43:21 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 12:43:21 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 12:43:32 --> Query error: Unknown column 'events_translates.title' in 'field list' - Invalid query: SELECT `events`.`id`, `events`.`date`, `events`.`image`, `events`.`google`, `events_translates`.`title`, `events_translates`.`description`, `events_translates`.`destination`
FROM `events`
WHERE `id` = '3'
ERROR - 2017-03-28 12:43:32 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 12:43:32 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 12:43:44 --> Query error: Unknown column 'events_translates.title' in 'field list' - Invalid query: SELECT `events`.`id`, `events`.`date`, `events`.`image`, `events`.`google`, `events_translates`.`title`, `events_translates`.`description`, `events_translates`.`destination`
FROM `events`
WHERE `id` = '3'
ERROR - 2017-03-28 12:43:44 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 12:43:44 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 12:44:24 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:44:24 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:44:24 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:44:24 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:45:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr' at line 1 - Invalid query: SELECT `events`.`id`, `events`.`date`, `events`.`image`, `events`.`google`, `events_translates`.`title`, `events_translates`.`description`, `events_translates`.`destination`, *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `events`.`id` DESC
 LIMIT 20
ERROR - 2017-03-28 12:45:12 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 12:45:12 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 12:45:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr' at line 1 - Invalid query: SELECT `events`.`id`, `events`.`date`, `events`.`image`, `events`.`google`, `events_translates`.`title`, `events_translates`.`description`, `events_translates`.`destination`, *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `events`.`id` DESC
 LIMIT 20
ERROR - 2017-03-28 12:45:13 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 12:45:13 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 12:47:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '*
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr' at line 1 - Invalid query: SELECT `events`.`id`, `events`.`date`, `events`.`image`, `events`.`google`, `events_translates`.`title`, `events_translates`.`description`, `events_translates`.`destination`, *
FROM `events`
JOIN `events_translates` ON `for_id` = `events`.`id`
WHERE `abbr` = 'bg'
ORDER BY `events`.`id` DESC
 LIMIT 20
ERROR - 2017-03-28 12:47:18 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 12:47:18 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 12:47:35 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:47:35 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:47:35 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:47:35 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:47:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:47:42 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:47:42 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:47:42 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:47:42 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:48:37 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:48:37 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:48:37 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:48:37 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:48:43 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:48:43 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:48:43 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:48:43 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:49:04 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:49:04 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:49:04 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:49:04 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:49:04 --> Severity: Notice --> Undefined index: date_created /var/www/html/thecolossus.bg/application/modules/admin/views/events/events.php 27
ERROR - 2017-03-28 12:49:04 --> Severity: Notice --> Undefined index: date_created /var/www/html/thecolossus.bg/application/modules/admin/views/events/events.php 27
ERROR - 2017-03-28 12:49:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:49:05 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:49:05 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:49:05 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:49:05 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:49:05 --> Severity: Notice --> Undefined index: date_created /var/www/html/thecolossus.bg/application/modules/admin/views/events/events.php 27
ERROR - 2017-03-28 12:49:05 --> Severity: Notice --> Undefined index: date_created /var/www/html/thecolossus.bg/application/modules/admin/views/events/events.php 27
ERROR - 2017-03-28 12:49:22 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:49:22 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:49:22 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:49:22 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:49:28 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:49:28 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:49:28 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:49:28 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:49:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:49:29 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:49:29 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:49:29 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:49:29 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:49:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:52:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:53:08 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:53:08 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:53:08 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:53:08 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:53:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:53:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:53:55 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 12:53:55 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 12:53:55 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 12:53:55 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 12:54:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:56:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:57:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:58:42 --> Severity: error --> Exception: Unable to locate the model you have specified: AboutusModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-28 12:58:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 12:58:42 --> Severity: error --> Exception: Unable to locate the model you have specified: AboutusModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-28 13:51:33 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/aboutus/questions.php 24
ERROR - 2017-03-28 13:51:33 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/aboutus/questions.php 24
ERROR - 2017-03-28 14:52:31 --> Severity: error --> Exception: Unable to locate the model you have specified: EmailsModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-28 14:52:33 --> Severity: error --> Exception: Unable to locate the model you have specified: EmailsModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-28 14:52:35 --> Severity: error --> Exception: Unable to locate the model you have specified: EmailsModel /var/www/html/thecolossus.bg/system/core/Loader.php 344
ERROR - 2017-03-28 14:54:25 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2017-03-28 14:54:26 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2017-03-28 14:54:42 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2017-03-28 14:55:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 14:55:44 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/aboutus/questions.php 24
ERROR - 2017-03-28 14:55:44 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/aboutus/questions.php 24
ERROR - 2017-03-28 14:55:54 --> 404 Page Not Found: ../modules/admin/controllers//index
ERROR - 2017-03-28 14:56:04 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/aboutus/questions.php 24
ERROR - 2017-03-28 14:56:04 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/aboutus/questions.php 24
ERROR - 2017-03-28 14:56:16 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:16 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:18 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:18 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:18 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:18 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:19 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:56:19 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/questions.php 24
ERROR - 2017-03-28 14:58:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 15:15:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 15:38:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 15:38:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 15:52:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 15:52:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 15:57:59 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/addquestion.php 15
ERROR - 2017-03-28 15:57:59 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/addquestion.php 15
ERROR - 2017-03-28 15:57:59 --> Severity: Notice --> Undefined variable: languages /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/addquestion.php 15
ERROR - 2017-03-28 15:57:59 --> Severity: Error --> Call to a member function result() on null /var/www/html/thecolossus.bg/application/modules/admin/views/contactus/addquestion.php 15
ERROR - 2017-03-28 15:58:21 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-28 15:58:21 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/modules/admin/controllers/contactus/Addquestion.php 25
ERROR - 2017-03-28 15:58:22 --> Severity: Notice --> Undefined property: CI::$LanguagesModel /var/www/html/thecolossus.bg/application/third_party/MX/Controller.php 59
ERROR - 2017-03-28 15:58:22 --> Severity: Error --> Call to a member function getLanguages() on null /var/www/html/thecolossus.bg/application/modules/admin/controllers/contactus/Addquestion.php 25
ERROR - 2017-03-28 16:06:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:06:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:12:32 --> Severity: Notice --> Undefined variable: insert_id /var/www/html/thecolossus.bg/application/modules/admin/models/ContactusModel.php 121
ERROR - 2017-03-28 16:12:32 --> Query error: Unknown column 'abbr' in 'field list' - Invalid query: INSERT INTO `questions_translates` (`question`, `answer`, `abbr`, `for_id`) VALUES ('1', '3', 'bg', NULL)
ERROR - 2017-03-28 16:12:32 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 16:12:32 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 16:12:48 --> Severity: Notice --> Undefined variable: insert_id /var/www/html/thecolossus.bg/application/modules/admin/models/ContactusModel.php 121
ERROR - 2017-03-28 16:12:48 --> Query error: Column 'for_id' cannot be null - Invalid query: INSERT INTO `questions_translates` (`question`, `answer`, `abbr`, `for_id`) VALUES ('1', '3', 'bg', NULL)
ERROR - 2017-03-28 16:12:48 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 16:12:48 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 16:12:49 --> Severity: Notice --> Undefined variable: insert_id /var/www/html/thecolossus.bg/application/modules/admin/models/ContactusModel.php 121
ERROR - 2017-03-28 16:12:49 --> Query error: Column 'for_id' cannot be null - Invalid query: INSERT INTO `questions_translates` (`question`, `answer`, `abbr`, `for_id`) VALUES ('1', '3', 'bg', NULL)
ERROR - 2017-03-28 16:12:49 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-28 16:12:49 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-28 16:13:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:13:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:28:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:28:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:30:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:30:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:32:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:40:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:42:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:42:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:44:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:46:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 16:57:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 17:11:06 --> 404 Page Not Found: /index
ERROR - 2017-03-28 17:11:06 --> 404 Page Not Found: /index
ERROR - 2017-03-28 17:11:06 --> 404 Page Not Found: /index
ERROR - 2017-03-28 17:11:06 --> 404 Page Not Found: /index
ERROR - 2017-03-28 17:11:19 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 17:11:19 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 17:11:19 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 17:11:19 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 17:11:26 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 17:11:26 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 17:11:26 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 17:11:26 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 17:11:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 17:17:00 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 17:17:00 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 17:17:00 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 17:17:00 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 17:17:02 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 17:17:02 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 17:17:02 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 17:17:02 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 17:17:03 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-28 17:17:03 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-28 17:17:03 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-28 17:17:03 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-28 17:18:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 17:30:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 17:32:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 17:33:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-28 17:55:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
