<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-26 09:46:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-26 09:46:21 --> 404 Page Not Found: /index
ERROR - 2017-04-26 17:08:09 --> 404 Page Not Found: /index
ERROR - 2017-04-26 17:08:09 --> 404 Page Not Found: /index
