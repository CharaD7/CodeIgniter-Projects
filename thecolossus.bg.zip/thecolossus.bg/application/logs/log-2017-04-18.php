<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-18 09:32:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-18 09:32:42 --> 404 Page Not Found: /index
ERROR - 2017-04-18 09:32:42 --> 404 Page Not Found: /index
ERROR - 2017-04-18 09:59:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-18 15:41:08 --> 404 Page Not Found: /index
ERROR - 2017-04-18 15:41:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
