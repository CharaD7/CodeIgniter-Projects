<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-05 09:39:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 09:39:30 --> 404 Page Not Found: /index
ERROR - 2017-04-05 09:39:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:00:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:12:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:15:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:15:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:18:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:18:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:18:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:26:04 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:26:04 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:26:06 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:26:07 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:27:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:27:05 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:27:05 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:27:06 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:27:06 --> 404 Page Not Found: /index
ERROR - 2017-04-05 10:34:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:34:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:49:47 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 10:49:47 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 10:49:47 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 10:50:03 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 10:50:03 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 10:50:03 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 10:50:14 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 10:50:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 10:50:14 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 10:50:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:52:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:57:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:58:04 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:59:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:59:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 10:59:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:00:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:01:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:01:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:07:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:08:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:11:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:15:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:16:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:16:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:16:21 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 11:16:21 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 11:16:21 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 11:16:21 --> Query error: Unknown column 'n_team_name' in 'field list' - Invalid query: UPDATE `teams` SET `n_team_name` = 'Панчарево1', `name` = 'Панчарево1'
WHERE `for_user` = '1'
AND `id` = '3'
ERROR - 2017-04-05 11:16:21 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-05 11:16:21 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-05 11:16:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:16:31 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 11:16:31 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 11:16:31 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 11:17:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:18:53 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 11:18:53 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 11:18:53 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 11:22:42 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 11:22:42 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 11:22:42 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 11:22:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:27:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:27:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:27:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:27:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:27:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:31:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:32:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:33:10 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 11:33:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 11:33:10 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 11:40:18 --> Severity: Warning --> Missing argument 1 for Myteam::index() /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 19
ERROR - 2017-04-05 11:40:41 --> Severity: Warning --> Missing argument 1 for Myteam::index() /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 19
ERROR - 2017-04-05 11:40:41 --> Severity: Notice --> Undefined variable: event_id /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 21
ERROR - 2017-04-05 11:40:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:40:43 --> Severity: Warning --> Missing argument 1 for Myteam::index() /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 19
ERROR - 2017-04-05 11:40:43 --> Severity: Notice --> Undefined variable: event_id /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php 21
ERROR - 2017-04-05 11:40:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:41:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:44:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:44:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:44:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:47:43 --> Severity: Notice --> Undefined variable: events /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 69
ERROR - 2017-04-05 11:47:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 69
ERROR - 2017-04-05 11:47:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:47:44 --> Severity: Notice --> Undefined variable: events /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 69
ERROR - 2017-04-05 11:47:44 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 69
ERROR - 2017-04-05 11:48:03 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:48:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:48:54 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:48:55 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:14 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:27 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:37 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:39 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:53 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:54 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:49:57 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:50:06 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:50:07 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:50:08 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:50:36 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:50:38 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:51:04 --> 404 Page Not Found: /index
ERROR - 2017-04-05 11:53:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 11:53:49 --> 404 Page Not Found: 
ERROR - 2017-04-05 11:54:04 --> 404 Page Not Found: ../modules/user/controllers/myteam//index
ERROR - 2017-04-05 11:54:05 --> 404 Page Not Found: ../modules/user/controllers/myteam//index
ERROR - 2017-04-05 11:54:06 --> 404 Page Not Found: 
ERROR - 2017-04-05 11:54:50 --> Severity: Warning --> Missing argument 2 for UsersModel::checkHaveITeam(), called in /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php on line 47 and defined /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 11
ERROR - 2017-04-05 11:54:50 --> Severity: Notice --> Undefined variable: event_id /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 13
ERROR - 2017-04-05 11:54:50 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 105
ERROR - 2017-04-05 11:54:51 --> Severity: Warning --> Missing argument 2 for UsersModel::checkHaveITeam(), called in /var/www/html/thecolossus.bg/application/modules/user/controllers/myteam/Myteam.php on line 47 and defined /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 11
ERROR - 2017-04-05 11:54:51 --> Severity: Notice --> Undefined variable: event_id /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 13
ERROR - 2017-04-05 11:54:51 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 105
ERROR - 2017-04-05 11:54:59 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 105
ERROR - 2017-04-05 11:56:55 --> 404 Page Not Found: 
ERROR - 2017-04-05 11:56:56 --> 404 Page Not Found: 
ERROR - 2017-04-05 12:01:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:01:46 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:01:46 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:01:46 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:01:46 --> Could not find the language line "pagination_first_link"
ERROR - 2017-04-05 12:01:46 --> Could not find the language line "pagination_next_link"
ERROR - 2017-04-05 12:01:46 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-04-05 12:01:46 --> Could not find the language line "pagination_last_link"
ERROR - 2017-04-05 12:01:54 --> 404 Page Not Found: 
ERROR - 2017-04-05 12:02:01 --> 404 Page Not Found: 
ERROR - 2017-04-05 12:02:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:02:40 --> 404 Page Not Found: 
ERROR - 2017-04-05 12:02:44 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:02:48 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:03:15 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:03:15 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:03:15 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:03:15 --> Severity: Notice --> Undefined index: for_event /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 31
ERROR - 2017-04-05 12:03:15 --> Query error: Unknown column 'fot_event' in 'field list' - Invalid query: INSERT INTO `teams` (`name`, `image`, `time_created`, `for_user`, `fot_event`) VALUES ('dqwdqw', 0, 1491382995, '1', NULL)
ERROR - 2017-04-05 12:03:15 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-05 12:03:15 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-05 12:04:11 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:04:11 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:04:11 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:04:11 --> Severity: Notice --> Undefined index: for_event /var/www/html/thecolossus.bg/application/modules/user/models/UsersModel.php 31
ERROR - 2017-04-05 12:04:11 --> Query error: Unknown column 'fot_event' in 'field list' - Invalid query: INSERT INTO `teams` (`name`, `image`, `time_created`, `for_user`, `fot_event`) VALUES ('dqwdqw', 0, 1491383051, '1', NULL)
ERROR - 2017-04-05 12:04:11 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-05 12:04:11 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-05 12:04:12 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:04:14 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:04:14 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:04:14 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:04:14 --> Query error: Unknown column 'fot_event' in 'field list' - Invalid query: INSERT INTO `teams` (`name`, `image`, `time_created`, `for_user`, `fot_event`) VALUES ('dqw', 0, 1491383054, '1', '2')
ERROR - 2017-04-05 12:04:14 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-05 12:04:14 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-05 12:04:17 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:04:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:04:25 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:04:26 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:04:26 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:04:26 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:04:26 --> 404 Page Not Found: ../modules/user/controllers/myteam//index
ERROR - 2017-04-05 12:05:11 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:05:13 --> Severity: Notice --> Undefined variable: myTeam /var/www/html/thecolossus.bg/application/modules/user/views/myteam/index.php 106
ERROR - 2017-04-05 12:05:21 --> Could not find the language line "pagination_first_link"
ERROR - 2017-04-05 12:05:21 --> Could not find the language line "pagination_next_link"
ERROR - 2017-04-05 12:05:21 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-04-05 12:05:21 --> Could not find the language line "pagination_last_link"
ERROR - 2017-04-05 12:07:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:08:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:16:37 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT *
FROM `events`
JOIN `events_translates` ON `events`.`id` = `events_translates`.`for_id`
WHERE `id` = '1'
AND `events_translates`.`abbr` = 'bg'
ERROR - 2017-04-05 12:16:37 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-05 12:16:37 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-05 12:16:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:17:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:17:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:22:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:25:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:25:55 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:25:55 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:25:55 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:26:00 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:26:00 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:26:00 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:27:08 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:27:08 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:27:08 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:27:44 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-05 12:27:44 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-05 12:27:44 --> Image Upload Error: <p>upload_no_file_selected</p>
ERROR - 2017-04-05 12:27:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:38:06 --> 404 Page Not Found: /index
ERROR - 2017-04-05 12:40:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:42:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:44:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:45:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:51:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:51:07 --> Could not find the language line "email"
ERROR - 2017-04-05 12:51:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:56:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:56:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 12:57:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 14:22:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 14:31:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 14:44:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:02:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:26:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:28:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:30:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:30:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:30:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:31:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:32:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:33:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:35:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:35:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:38:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:41:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:45:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:45:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:45:45 --> 404 Page Not Found: /index
ERROR - 2017-04-05 15:45:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:46:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:46:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:48:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:49:49 --> Could not find the language line "verify_link"
ERROR - 2017-04-05 15:50:04 --> Could not find the language line "verify_link"
ERROR - 2017-04-05 15:50:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 15:51:24 --> 404 Page Not Found: /index
ERROR - 2017-04-05 16:02:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:02:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:04:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:04:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:04:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:04:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:04:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:05:52 --> 404 Page Not Found: /index
ERROR - 2017-04-05 16:10:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:13:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:49:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:50:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:50:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-05 16:51:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
