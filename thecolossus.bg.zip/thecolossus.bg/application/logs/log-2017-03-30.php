<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-30 09:39:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:39:36 --> 404 Page Not Found: /index
ERROR - 2017-03-30 09:39:36 --> 404 Page Not Found: /index
ERROR - 2017-03-30 09:39:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:40:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:41:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:42:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:43:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:43:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:44:36 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-30 09:44:36 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-30 09:44:36 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-30 09:44:36 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-30 09:44:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:45:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 09:56:10 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-30 09:56:10 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-30 09:56:10 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-30 09:56:10 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-30 09:56:14 --> 404 Page Not Found: /index
ERROR - 2017-03-30 09:56:14 --> 404 Page Not Found: /index
ERROR - 2017-03-30 09:56:14 --> 404 Page Not Found: /index
ERROR - 2017-03-30 09:56:14 --> 404 Page Not Found: /index
ERROR - 2017-03-30 10:06:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:13:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:14:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:14:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:18:28 --> Severity: Notice --> Undefined variable: numUnReadedEmails /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 139
ERROR - 2017-03-30 10:18:28 --> Severity: Notice --> Undefined variable: last4unreaded /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 142
ERROR - 2017-03-30 10:18:28 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 142
ERROR - 2017-03-30 10:18:29 --> Severity: Notice --> Undefined variable: numUnReadedEmails /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 139
ERROR - 2017-03-30 10:18:29 --> Severity: Notice --> Undefined variable: last4unreaded /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 142
ERROR - 2017-03-30 10:18:29 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/thecolossus.bg/application/modules/user/views/parts/header.php 142
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:24 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:42 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:42 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:22:56 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:03 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:23:09 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:51 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:23:59 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:24:45 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:24:45 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:24:45 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:24:45 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:26:05 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:26:05 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:26:05 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:26:05 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:26:17 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:26:17 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:03 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:03 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:10 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:10 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:47 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:47 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:47 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:27:47 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:29:35 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:29:35 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:30:07 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:30:07 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:30:07 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:30:07 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 10:31:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:37:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:37:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:37:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:41:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:42:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:42:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:42:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:43:27 --> 404 Page Not Found: /index
ERROR - 2017-03-30 10:43:27 --> 404 Page Not Found: /index
ERROR - 2017-03-30 10:44:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:44:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:51:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:52:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:56:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:57:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 10:58:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:09:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:13:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:13:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:13:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:19:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:20:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:20:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:25:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:26:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:28:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:32:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:32:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:37:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:39:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:41:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:43:18 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:44:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:44:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:50:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:50:59 --> Could not find the language line "menu"
ERROR - 2017-03-30 11:52:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 11:59:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:00:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:02:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:07:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:08:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:09:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:10:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:10:48 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 12:12:44 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 12:18:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:28:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:28:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:28:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:28:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:28:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:34:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:39:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:39:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:50:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:52:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 12:53:52 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 13:43:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 15:52:35 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-03-30 17:19:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-30 17:36:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
