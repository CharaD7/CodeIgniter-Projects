<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-11 14:28:37 --> 404 Page Not Found: /index
ERROR - 2017-04-11 14:28:37 --> 404 Page Not Found: /index
