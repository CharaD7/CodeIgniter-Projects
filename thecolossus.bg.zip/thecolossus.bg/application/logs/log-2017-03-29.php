<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-03-29 09:25:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:25:38 --> 404 Page Not Found: /index
ERROR - 2017-03-29 09:25:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:25:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:25:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:38:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:38:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:38:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:49:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:50:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:50:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:50:51 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-29 09:50:51 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-29 09:50:51 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-29 09:50:51 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-29 09:51:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:51:57 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-29 09:51:57 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-29 09:51:57 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-29 09:51:57 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-29 09:51:59 --> 404 Page Not Found: /index
ERROR - 2017-03-29 09:51:59 --> 404 Page Not Found: /index
ERROR - 2017-03-29 09:51:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 09:51:59 --> 404 Page Not Found: /index
ERROR - 2017-03-29 09:51:59 --> 404 Page Not Found: /index
ERROR - 2017-03-29 10:11:52 --> 404 Page Not Found: /index
ERROR - 2017-03-29 10:11:52 --> 404 Page Not Found: /index
ERROR - 2017-03-29 10:37:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 10:39:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 10:40:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 10:40:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:03:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:13:06 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:19:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:20:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:31:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:34:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:52:16 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:53:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:54:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:57:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 11:58:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:01:11 --> Severity: Error --> Call to undefined function currencies() /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 44
ERROR - 2017-03-29 12:01:12 --> Severity: Error --> Call to undefined function currencies() /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 44
ERROR - 2017-03-29 12:04:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:05:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:09:37 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:12:12 --> Query error: Duplicate entry 'asd' for key 'my_key' - Invalid query: INSERT INTO `texts` (`admin_info`, `my_key`) VALUES ('asdas', 'asd')
ERROR - 2017-03-29 12:12:12 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-29 12:12:12 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-29 12:14:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:15:59 --> Query error: Duplicate entry 'dqwdqw' for key 'my_key' - Invalid query: INSERT INTO `texts` (`admin_info`, `my_key`) VALUES ('dqwdqw', 'dqwdqw')
ERROR - 2017-03-29 12:15:59 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-29 12:15:59 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-29 12:16:00 --> Query error: Duplicate entry 'dqwdqw' for key 'my_key' - Invalid query: INSERT INTO `texts` (`admin_info`, `my_key`) VALUES ('dqwdqw', 'dqwdqw')
ERROR - 2017-03-29 12:16:00 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-29 12:16:00 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-29 12:16:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:18:51 --> Query error: Duplicate entry 'dqwdqw' for key 'my_key' - Invalid query: INSERT INTO `texts` (`admin_info`, `my_key`) VALUES ('dqwdqwqwd', 'dqwdqw')
ERROR - 2017-03-29 12:18:51 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-03-29 12:18:51 --> Could not find the language line "db_error_heading"
ERROR - 2017-03-29 12:21:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:23:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:27:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:30:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:34:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:34:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:34:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:36:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:37:18 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-29 12:37:18 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-29 12:37:18 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-29 12:37:18 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-29 12:37:23 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-29 12:37:23 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-29 12:37:23 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-29 12:37:23 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-29 12:37:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:37:34 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-29 12:37:34 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-29 12:37:34 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-29 12:37:34 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-29 12:37:38 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:38 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:38 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:38 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:41 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:41 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:41 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:41 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:45 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:45 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:45 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:37:45 --> 404 Page Not Found: /index
ERROR - 2017-03-29 12:44:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:49:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:51:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:53:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 12:53:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 13:50:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:09:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:19:59 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 37
ERROR - 2017-03-29 14:19:59 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 41
ERROR - 2017-03-29 14:20:00 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 37
ERROR - 2017-03-29 14:20:00 --> Severity: Notice --> Undefined variable: id /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 41
ERROR - 2017-03-29 14:20:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:21:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:25:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:26:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:33:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:33:22 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:33:42 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:33:42 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:33:43 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:33:58 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:33:59 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:35:48 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:38:11 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 42
ERROR - 2017-03-29 14:38:12 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 42
ERROR - 2017-03-29 14:38:46 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:38:47 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:11 --> Severity: Warning --> Illegal offset type /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 44
ERROR - 2017-03-29 14:39:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:42:38 --> Severity: Compile Error --> Cannot use [] for reading /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 43
ERROR - 2017-03-29 14:51:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:52:38 --> Severity: Parsing Error --> syntax error, unexpected '$row' (T_VARIABLE) /var/www/html/thecolossus.bg/application/modules/admin/models/TextsModel.php 42
ERROR - 2017-03-29 14:52:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:53:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:53:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:53:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:54:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 14:59:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:04:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:04:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:09:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:12 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:18 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Undefined variable: language /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Notice --> Trying to get property of non-object /var/www/html/thecolossus.bg/application/modules/admin/views/texts/index.php 34
ERROR - 2017-03-29 15:11:31 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:11:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:24:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:25:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:25:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:25:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:34:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:34:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:35:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:37:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:39:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:39:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:42:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:43:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:47:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:47:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:47:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:47:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:50:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:51:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:51:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:52:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:52:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:55:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:55:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:56:06 --> 404 Page Not Found: /index
ERROR - 2017-03-29 15:58:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:59:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 15:59:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:01:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:01:03 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:01:03 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:01:03 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:01:03 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:01:06 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:01:06 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:01:06 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:17 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:17 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:17 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:17 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:06:34 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:34 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:35 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:35 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:35 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:35 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:36 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:36 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:37 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:06:37 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:07:44 --> Severity: Notice --> Undefined variable: rules /var/www/html/thecolossus.bg/application/views/register/index.php 58
ERROR - 2017-03-29 16:07:45 --> Severity: Notice --> Undefined variable: rules /var/www/html/thecolossus.bg/application/views/register/index.php 58
ERROR - 2017-03-29 16:08:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:08:25 --> Could not find the language line "idea"
ERROR - 2017-03-29 16:08:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:09:17 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:09:57 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:09:57 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:09:57 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:09:57 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:10:10 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:11:41 --> Severity: Notice --> Undefined variable: u /var/www/html/thecolossus.bg/application/views/parts/header.php 52
ERROR - 2017-03-29 16:11:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:14:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:14:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:19:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:19:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:21:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:22:21 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:26:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:26:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:27:25 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:29:23 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:32:09 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:38:30 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:39:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:41:12 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:41:15 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:41:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:41:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:41:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:42:55 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:42:55 --> 404 Page Not Found: /index
ERROR - 2017-03-29 16:48:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:48:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:51:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 16:52:02 --> Could not find the language line "pagination_first_link"
ERROR - 2017-03-29 16:52:02 --> Could not find the language line "pagination_next_link"
ERROR - 2017-03-29 16:52:02 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-03-29 16:52:02 --> Could not find the language line "pagination_last_link"
ERROR - 2017-03-29 17:22:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:32:14 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:34:00 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:36:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:38:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:41:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:42:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:43:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:44:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:44:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:47:44 --> 404 Page Not Found: /index
ERROR - 2017-03-29 17:47:48 --> 404 Page Not Found: /index
ERROR - 2017-03-29 17:48:25 --> 404 Page Not Found: /index
ERROR - 2017-03-29 17:48:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:51:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:51:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:51:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:56:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-03-29 17:58:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
