<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-20 09:48:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-20 09:48:13 --> 404 Page Not Found: /index
ERROR - 2017-04-20 09:48:13 --> 404 Page Not Found: /index
ERROR - 2017-04-20 15:50:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-20 15:51:10 --> Language file contains no data: language/bulgarian/upload_lang.php
ERROR - 2017-04-20 15:51:10 --> Could not find the language line "upload_no_file_selected"
ERROR - 2017-04-20 15:51:10 --> Image Upload Error: <p>upload_no_file_selected</p>
