<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-03 09:22:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:22:43 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:22:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:22:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:27:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:27:27 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:27:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:38:20 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:38:46 --> Could not find the language line "pagination_first_link"
ERROR - 2017-04-03 09:38:46 --> Could not find the language line "pagination_next_link"
ERROR - 2017-04-03 09:38:46 --> Could not find the language line "pagination_prev_link"
ERROR - 2017-04-03 09:38:46 --> Could not find the language line "pagination_last_link"
ERROR - 2017-04-03 09:39:03 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:03 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:39:03 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:03 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:05 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:05 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:06 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:06 --> 404 Page Not Found: /index
ERROR - 2017-04-03 09:39:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 09:57:57 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 10:14:22 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 10:49:08 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:09:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:14:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:14:45 --> 404 Page Not Found: /index
ERROR - 2017-04-03 11:14:51 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:15:03 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:15:58 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:16:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "register_team"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "log_me"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "about_us"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "events"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "contacts"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "about_us"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "events"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "see_all_events"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "idea"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "contact_with_us"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "register_team_2"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "footer_home"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "footer_about_us"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "footer_events"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "footer_faq"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "login"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "your_email"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "your_password"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "log_me"
ERROR - 2017-04-03 11:17:55 --> Could not find the language line "cancel"
ERROR - 2017-04-03 11:17:55 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:17:59 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:18:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:19:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:21:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:28:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:30:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 11:52:07 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:06:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:06:51 --> 404 Page Not Found: /index
ERROR - 2017-04-03 12:06:51 --> 404 Page Not Found: /index
ERROR - 2017-04-03 12:15:13 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:18:23 --> Severity: Warning --> get_browser(): browscap ini directive not set /var/www/html/thecolossus.bg/application/views/home/index.php 2
ERROR - 2017-04-03 12:20:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:22:38 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:24:36 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:26:12 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 12:27:24 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:27:56 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:28:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 12:58:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 14:30:53 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 14:34:29 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:34:32 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:35:02 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:41:16 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:41:34 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 14:41:36 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:41:39 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:41:49 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:41:49 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 14:41:49 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:42:01 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 14:42:01 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 14:42:02 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 15:09:59 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 15:10:02 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 15:10:11 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 15:10:11 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:10:12 --> 404 Page Not Found: ../modules/user/controllers/home//index
ERROR - 2017-04-03 15:27:52 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:28:10 --> Query error: Table 'thecolossus.profiles' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `profiles`
WHERE `email` = 'kiro2424@gmail.com'
ERROR - 2017-04-03 15:28:10 --> Language file contains no data: language/bulgarian/db_lang.php
ERROR - 2017-04-03 15:28:10 --> Could not find the language line "db_error_heading"
ERROR - 2017-04-03 15:31:05 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:31:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:38:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:44:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:49:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:49:16 --> Severity: Error --> Call to undefined function geterror() /var/www/html/thecolossus.bg/application/views/contactus/index.php 73
ERROR - 2017-04-03 15:49:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:49:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:49:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 15:49:58 --> Severity: Error --> Call to undefined function gaterror() /var/www/html/thecolossus.bg/application/views/register/index.php 68
ERROR - 2017-04-03 15:52:11 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 16:02:15 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:02:50 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:06:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:06:54 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:07:02 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:08:47 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:13:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:15:28 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:15:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:19:26 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:24:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:32:39 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-03 16:39:19 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 16:39:21 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 16:39:43 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 16:40:14 --> 404 Page Not Found: ../modules/user/controllers//index
ERROR - 2017-04-03 16:40:50 --> 404 Page Not Found: ../modules/user/controllers//index
