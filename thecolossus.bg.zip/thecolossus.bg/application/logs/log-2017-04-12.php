<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-04-12 09:58:03 --> 404 Page Not Found: /index
ERROR - 2017-04-12 09:58:03 --> 404 Page Not Found: /index
ERROR - 2017-04-12 10:48:29 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-12 14:39:10 --> 404 Page Not Found: /index
ERROR - 2017-04-12 14:39:10 --> 404 Page Not Found: /index
ERROR - 2017-04-12 15:25:40 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-12 16:29:35 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2017-04-12 16:29:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_intl.dll' - /usr/lib/php/20131226/php_intl.dll: cannot open shared object file: No such file or directory Unknown 0
