<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Events extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = array();
        $head = array();
        $data['coming_events'] = $this->PublicModel->getComingEvents();
        $this->render('events/index', $head, $data);
    }

}
