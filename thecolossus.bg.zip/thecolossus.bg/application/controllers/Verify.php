<?php

defined('BASEPATH') OR exit('No direct script access allowed');
/* Set internal character encoding to UTF-8 */
mb_internal_encoding("UTF-8");

class Verify extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('file');
    }

    public function index($md5)
    {
        if (!$md5 || !preg_match('/^[a-f0-9]{32}$/', $md5)) {
            show_404();
        }
        $user = $this->PublicModel->getMemberByHash($md5);
        if (empty($user)) {
            show_404();
        }
        if (isset($_POST['name'])) {
            $result = $this->verifyData();
            if ($result === true) {
                $_POST['hash'] = $md5;
                $_POST['image'] = uploader('./attachments/membersimages/');
                $this->PublicModel->verifyUser($_POST);
                redirect(lang_url('verify/' . $md5));
            } else {
                $this->session->set_flashdata('name', $_POST['name']);
                $this->session->set_flashdata('family', $_POST['family']);
                $this->session->set_flashdata('phone', $_POST['phone']);

                $this->session->set_flashdata('resultVerify', $result);
                redirect(lang_url('verify/' . $md5));
            }
        }
        $data = array();
        $head = array();
        $data['user'] = $user;
        $this->render('verify/index', $head, $data);
    }

    private function verifyData()
    {
        $errors = array();
        if (mb_strlen(trim($_POST['name'])) == 0) {
            $errors[] = lang('empty_name');
        }
        if (mb_strlen(trim($_POST['family'])) == 0) {
            $errors[] = lang('empty_family');
        }
        if (mb_strlen(trim($_POST['phone'])) == 0) {
            $errors[] = lang('empty_phone');
        }
        if (empty($errors)) {
            return true;
        } else {
            return $errors;
        }
    }

}
