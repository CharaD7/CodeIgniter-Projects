<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = array();
        $head = array();
        if (isset($_POST['email'])) {
            $invalid_login = $this->logMe();
            $this->session->set_flashdata('wrongLogin', $invalid_login);
            redirect(lang_url('login'));
        }
        $this->render('login/index', $head, $data);
    }

    private function logMe()
    {
        $result = $this->PublicModel->checkLogin($_POST);
        if ($result > 0) {
            $this->setUserLogin($_POST['email']);
        } else {
            return lang('invalid_login_details');
        }
    }

}
