<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Contactus extends MY_Controller
{

    private $siteEmail;

    public function __construct()
    {
        parent::__construct();
        $this->siteEmail = $this->PublicModel->getOneValueStore('_siteEmail');
    }

    public function index()
    {
        $data = array();
        $head = array();
        if (isset($_POST['message'])) {
            $result = $this->sendEmail();
            $this->session->set_flashdata('resultSend', $result);
            redirect(lang_url('contactus'));
        }
        $data['questions'] = $this->PublicModel->getQuestions();
        $this->render('contactus/index', $head, $data);
    }

    private function sendEmail()
    {
        $errors = array();
        if (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = lang('invalid_email');
        }
        if (mb_strlen(trim($_POST['message'])) == 0) {
            $errors[] = lang('message_empty');
        }
        @$_SESSION['sended_emails'] += 1; //noob prevent of spam :)
        if (empty($errors) && $_SESSION['sended_emails'] < 10) {
            $this->load->library('email');

            $this->email->from($_POST['email'], $_POST['name']);
            $this->email->to($this->siteEmail);

            $this->email->subject('Message from thecolossus.bg');
            $this->email->message($_POST['message']);

            $this->email->send();
            $this->saveEmailToDb();
            return true;
        }
        $this->session->set_flashdata('the_name', $_POST['name']);
        $this->session->set_flashdata('the_msg', $_POST['message']);
        $this->session->set_flashdata('the_email', $_POST['email']);
        return $errors;
    }

    private function saveEmailToDb()
    {
        $this->PublicModel->saveEmailToDb($_POST);
    }

}
