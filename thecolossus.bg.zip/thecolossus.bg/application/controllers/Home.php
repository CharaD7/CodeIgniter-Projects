<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    private $homeBottomImagesDir = "attachments/homebottomimages/";

    public function index()
    {
        $data = array();
        $head = array();
        $data['first_coming_evenet'] = $this->PublicModel->getFirstComingEvent();
        $data['images'] = $this->getHomeBottomImages();
        $this->render('home/index', $head, $data);
    }

    private function getHomeBottomImages()
    {
        $dir = $this->homeBottomImagesDir;
        $images = array();
        if (is_dir($dir)) {
            if ($dh = opendir($dir)) {
                $i = 1;
                while (($file = readdir($dh)) !== false) {
                    if (is_file($dir . $file)) {
                        $images[] = base_url($dir . $file);
                        $i++;
                    }
                }
                closedir($dh);
            }
        }
        return $images;
    }

    public function sitemap()
    {
        header("Content-Type:text/xml");
        echo '<?xml version="1.0" encoding="UTF-8"?>
                <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
        $result = $this->PublicModel->getTeamsIds(1000);
        foreach ($result as $row) {
            $parse = parse_url(base_url());
            echo '<url>
            <loc>http://team-' . $row->id . '.' . $parse['host'] . '</loc>
            <changefreq>monthly</changefreq>
            <priority>0.1</priority>
            </url>';
        }
        echo '</urlset>';
    }

}
