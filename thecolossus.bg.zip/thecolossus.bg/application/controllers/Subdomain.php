<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Subdomain extends MY_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = array();
        $head = array();
        $exp = explode('.', $_SERVER['HTTP_HOST']);
        $id = explode('-', $exp[0]);
        if (!is_numeric($id[1])) {
            redirect(base_url());
        }
        $data['team'] = $team = $this->PublicModel->getOneTeam($id[1]);
        if (!empty($team)) {
            $user = $this->PublicModel->getUserForTeam($team['id']);
            $data['members'] = $this->PublicModel->getMembersForTeam($team['id']);
            $data['members'][] = $user;
            $this->load->view('subdomain/header', $head);
            $this->load->view('subdomain/index', $data);
            $this->load->view('subdomain/footer');
        } else {
            redirect(base_url());
        }
    }

    public function share($team_id)
    {
        $result = $this->PublicModel->setShare($team_id);
        if ($result == true) {
            redirect('https://www.facebook.com/sharer/sharer.php?u=' . $_SERVER['HTTP_HOST']);
        } else {
            show_404();
        }
    }

}
