var lang = {
    yes: "Yes",
    no: "No",
    too_short_team_name: "Please enter team name!",
    invalid_email: "Invalid email address!"
};