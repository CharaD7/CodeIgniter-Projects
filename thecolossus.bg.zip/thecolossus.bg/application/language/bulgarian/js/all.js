var lang = { 
    yes: "Да",
    no: "Не",
    too_short_team_name: "Не сте въвели име на отбора!",
    invalid_email: "Невалиден имейл адрес!"
};