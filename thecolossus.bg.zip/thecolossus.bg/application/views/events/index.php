<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="inner-page">
    <div class="top-bg contact-us-bg">
        <h1><?= lang('events') ?></h1>
    </div> 
</div>
<div class="info-part">
    <h1 style="margin-bottom: 0;"><?= lang('comming_events') ?></h1>
</diV>
<div id="carouselEvents" class="carousel slide">
    <div class="carousel-inner" role="listbox">
        <?php
        $i = 0;
        foreach ($coming_events as $coming_event) {
            ?>
            <div class="item<?= $i == 0 ? ' active' : '' ?>">
                <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                    <div class="event">
                        <div class="image">
                            <img src="<?= base_url('attachments/eventsimages/' . $coming_event['image']) ?>" style="  width:100%;">
                            <div class="date"><?= date('d F', $coming_event['date']) ?><br><?= date('Y', $coming_event['date']) ?></div>
                        </div>
                        <div class="caption">
                            <h4>
                                <?= $coming_event['title'] ?>
                            </h4>
                            <div class="info">
                                <?= $coming_event['description'] ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
            <?php
            $i++;
        }
        ?>
        <a class="left carousel-control" href="#carouselEvents" role="button" data-slide="prev"> 
        </a>
        <a class="right carousel-control" href="#carouselEvents" role="button" data-slide="next"> 
        </a>
    </div> 
</div> 
<div class="info-part silver">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('idea') ?></h1>
                <div>
                    <?= $idea_text ?>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('#carouselEvents').carousel({
            interval: 10000;
        });

    });
</script>