<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="<?= MY_LANGUAGE_ABBR ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Bootstrap 101 Template</title> 
        <link href="<?= base_url('assets/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"> 
        <link href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">
        <link href="<?= base_url('assets/public/css/general.css') ?>" rel="stylesheet">
        <script src="<?= base_url('assets/jquery/jquery.min.js') ?>"></script> 
        <script src="<?= base_url('loadlanguage/all.js') ?>"></script>
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body> 
        <nav class="navbar navbar-colossus navbar-fixed-top">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#topNav">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?= lang_url() ?>">
                        <img src="<?= base_url('assets/public/imgs/logo.png') ?>" alt="the colossus bulgaria">
                    </a>
                </div>
                <div class="collapse navbar-collapse" id="topNav">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="<?= lang_url('register') ?>"><?= lang('register_team') ?></a></li>
                        <li><a href="javascript:void(0);" data-toggle="modal" data-target="#modalLogin"><?= lang('log_me') ?></a></li>
                        <li><a <?= uri_string() == 'aboutus' ? 'class="active"' : '' ?> href="<?= lang_url('aboutus') ?>"><?= lang('about_us') ?></a></li>
                        <li><a href="<?= lang_url('events') ?>"><?= lang('events') ?></a></li> 
                        <li><a href="<?= lang_url('contactus') ?>"><?= lang('contacts') ?></a></li> 
                    </ul>
                </div>
            </div>
        </nav>
        <div class="languages-bar">
            <a role="button" data-toggle="collapse" href="#languages-bar" aria-expanded="false" aria-controls="languages-bar">
                <img src="<?= base_url('attachments/langflags/' . $my_lang_flag) ?>" alt="English">
            </a>
            <ul class="list-langs collapse" id="languages-bar">
                <?php
                foreach ($languages as $language) {
                    if ($language['abbr'] == MY_DEFAULT_LANGUAGE_ABBR) {
                        $cr = trim(uri_string(), '/');
                        if (strlen($cr) == 2) {
                            $change_url = base_url();
                        } else {
                            $change_url = base_url(preg_replace('/' . MY_LANGUAGE_ABBR . '\//', '', uri_string()));
                        }
                    } else {
                        $u = preg_replace('/' . $language['abbr'] . '\//', '', uri_string());
                        $change_url = base_url($language['abbr'] . '/' . $u);
                    }
                    ?>
                    <li>
                        <a href="<?= $change_url ?>">
                            <img src="<?= base_url('attachments/langflags/' . $language['flag']) ?>" alt="<?= $language['name'] ?>">
                            <span><?= ucfirst($language['name']) ?></span>
                        </a>
                    </li>
                <?php } ?> 
            </ul>
        </div>