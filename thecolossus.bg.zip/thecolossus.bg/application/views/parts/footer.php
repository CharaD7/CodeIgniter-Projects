<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<footer>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-4">
                <div class="footer-left">
                    <h3>The <span>COLOSSUS</span></h3>
                    <p class="footer-links"> 
                        <a href="<?= lang_url('aboutus') ?>"><?= lang('footer_about_us') ?></a>
                        ·
                        <a href="<?= lang_url('events') ?>"><?= lang('footer_events') ?></a>
                        ·
                        <a href="<?= lang_url('contactus#faqAccordion') ?>"><?= lang('footer_faq') ?></a>
                        ·
                        <a href="<?= base_url('sitemap.xml') ?>">XML</a>
                    </p>
                    <p class="footer-company-name">The Colossus &copy; 2017</p>
                </div>
            </div>
            <div class="col-sm-3 col-md-4">
                <div class="footer-center">
                    <div>
                        <i class="fa fa-map-marker"></i>
                        <p><?= $_siteLocation ?></p>
                    </div>
                    <div>
                        <i class="fa fa-phone"></i>
                        <p><?= $_sitePhone ?></p>
                    </div>
                    <div>
                        <i class="fa fa-envelope"></i>
                        <p><a href="mailto:<?= $_siteEmail ?>"><?= $_siteEmail ?></a></p>
                    </div>
                </div>
            </div>
            <div class="col-sm-5 col-md-4">
                <div class="footer-company-about"> 
                    <?= $footer_text ?>
                </div>
                <div class="footer-icons">
                    <a href="<?= $_facebook ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                    <a href="<?= $_instagram ?>" target="_blank"><i class="fa fa-instagram"></i></a>
                    <a href="<?= $_youtube ?>" target="_blank"><i class="fa fa-youtube"></i></a>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Modal Login -->
<div class="modal fade" id="modalLogin" tabindex="-1" role="dialog" aria-labelledby="modalLogin">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <form method="POST" action="<?= lang_url('login') ?>" class="site-form">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title"><?= lang('login') ?></h4>
                </div>
                <div class="modal-body"> 
                    <div class="row">
                        <div class="col-sm-6 col-sm-offset-3">
                            <div class="form-group"> 
                                <input type="text" name="email" value="" placeholder="<?= lang('your_email') ?>" class="form-control field text-center">
                            </div>
                            <div class="form-group" style="margin-bottom: 0;"> 
                                <input type="password" name="password" value="" placeholder="<?= lang('your_password') ?>" class="form-control field text-center">
                            </div> 
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-red"><?= lang('log_me') ?></button>
                    <button type="button" class="btn btn-default close-btn" data-dismiss="modal"><?= lang('cancel') ?></button> 
                </div>
            </form> 
        </div>
    </div>
</div>
<script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/public/js/general.js') ?>"></script>
<script src="<?= base_url('assets/public/js/placeholders.min.js') ?>"></script>
</body>
</html>