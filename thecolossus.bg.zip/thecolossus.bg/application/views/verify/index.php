<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="verify-inner">
    <div class="container-fluid"> 
        <div class="row">
            <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">
                <form class="form-verifing site-form" method="POST" action="" enctype="multipart/form-data">
                    <input type="hidden" value="<?= $user['id'] ?>" name="user_id">
                    <?php if (!$user['verified']) { ?>
                        <h2>
                            <img src="<?= base_url('assets/user/imgs/notok.png') ?>" alt="not verified">
                            <?= lang('this_user_not_virified') ?>
                        </h2>
                    <?php } else { ?> 
                        <h2>
                            <img src="<?= base_url('assets/user/imgs/ok.png') ?>" alt="Verified">
                            <?= lang('this_user_virified') ?>
                        </h2>
                    <?php } ?>
                    <div class="form-group">
                        <label><?= lang('your_email') ?>:</label>
                        <input type="text" class="form-control field" value="<?= $user['email'] ?>" readonly>
                    </div>
                    <div class="form-group">
                        <label><?= lang('your_name') ?>:</label>
                        <input type="text" name="name" value="<?= $this->session->flashdata('name') ?>" class="form-control field">
                    </div>
                    <div class="form-group">
                        <label><?= lang('your_family') ?>:</label>
                        <input type="text" name="family" value="<?= $this->session->flashdata('family') ?>" class="form-control field">
                    </div>
                    <div class="form-group">
                        <label><?= lang('your_phone') ?>:</label>
                        <input type="text" name="phone" value="<?= $this->session->flashdata('phone') ?>" class="form-control field">
                    </div>
                    <div class="form-group">
                        <label><?= lang('your_picture') ?>:</label>
                        <input type="file" name="input_file">
                    </div>
                    <button type="submit" class="btn btn-default"><?= !$user['verified'] ? lang('verifiy_btn') : lang('verifiy_update_btn') ?></button>
                </form> 
            </div>
        </div>
    </div>
</div>
<?php
if ($this->session->flashdata('resultVerify')) {
    geterror($this->session->flashdata('resultVerify'));
}
?>