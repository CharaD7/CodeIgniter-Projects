<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="container">
    <div class="facebook-share">
        <a href="<?= base_url('fbshare/' . $team['id']) ?>">
            <img src="<?= base_url('assets/public/imgs/Share-on-Facebook-LG.png') ?>" alt="Facebook share The Colossus">
        </a>
    </div>
    <div class="team">
        <div class="colossus-logo">
            <a href="<?= base_url() ?>">
                <img alt="The Colossus Logo" src="<?= base_url('assets/public/imgs/logo.png') ?>">
            </a>
        </div>
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <div class="team-header">
                    <div class="team-title">
                        <h1><?= $team['name'] ?></h1>
                    </div>
                    <div class="team-logo">
                        <?php
                        $image = false;
                        if ($team['image'] != null && $team['image'] != false && is_file('attachments/teamslogos/' . $team['image'])) {
                            $image = base_url('attachments/teamslogos/' . $team['image']);
                        }
                        if ($image != false) {
                            ?>
                            <img src="<?= $image ?>" class="img-thumbnail img-circle" alt="<?= $team['name'] ?> Logo">
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
        <div class="members-header">
            <?= lang('members') ?>
        </div>
        <div class="members">
            <div class="row">
                <?php foreach ($members as $member) { ?>
                    <div class="col-sm-4 col-md-3">
                        <div class="member">
                            <?php
                            $image_dir = 'membersimages';
                            if (isset($member['is_user'])) {
                                $image_dir = 'usersimages';
                            }
                            $image = base_url('assets/user/imgs/defaultProfilePic.png');
                            if ($member['image'] != null && $member['image'] != false && is_file('attachments/membersimages/' . $member['image'])) {
                                $image = base_url('attachments/' . $image_dir . '/' . $member['image']);
                            }
                            ?>
                            <img src="<?= $image ?>" alt="The Colossus User Image" class="img-thumbnail img-responsive">
                            <h2><?= $member['name'] . ' ' . $member['family'] ?></h2>
                        </div>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="footer">
            <a href="<?= base_url() ?>"><?= base_url() ?></a>
        </div>
    </div>
</div>