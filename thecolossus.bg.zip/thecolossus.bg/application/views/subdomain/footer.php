<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script> 
<script src="<?= base_url('assets/public/js/subdomain.js') ?>"></script> 
</body>
</html>