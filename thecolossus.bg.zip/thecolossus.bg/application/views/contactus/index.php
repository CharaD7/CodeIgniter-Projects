<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="inner-page">
    <div class="top-bg contact-us-bg">
        <h1><?= lang('contacts') ?></h1>
    </div> 
</div>
<div class="info-part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('waiting_your_questions') ?></h1>
                <form method="POST" action="" class="site-form" id="contact-form">
                    <div class="form-group"> 
                        <input type="text" name="name" value="<?= trim($this->session->flashdata('the_name')) ?>" placeholder="<?= lang('your_name') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="text" name="email" value="<?= trim($this->session->flashdata('the_email')) ?>" placeholder="<?= lang('your_email') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <textarea name="message" placeholder="<?= lang('your_message') ?>" class="form-control field area"><?= trim($this->session->flashdata('the_msg')) ?></textarea>
                    </div>
                    <div class="form-group"> 
                        <a href="javascript:void(0);" class="btn btn-lg btn-red" onclick="contactMe()"><?= lang('send_us_message') ?></a>
                    </div>
                </form>
                <hr>
                <div class="text-left">
                    <i class="fa fa-phone contacts-i"></i><?= $_sitePhone ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="info-part silver">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('faq') ?></h1>
                <div class="panel-group" id="faqAccordion">
                    <?php
                    $i = 0;
                    foreach ($questions as $question) {
                        ?>
                        <div class="panel panel-default">
                            <div class="panel-heading accordion-toggle question-toggle collapsed" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question<?= $i ?>">
                                <h4 class="panel-title">
                                    <a href="javascript:void(0);" class="ing"><?= $question['question'] ?></a>
                                </h4>
                            </div>
                            <div id="question<?= $i ?>" class="panel-collapse collapse">
                                <div class="panel-body">
                                    <h5><span class="label label-red"><?= lang('answer') ?></span></h5>
                                    <p>
                                        <?= $question['answer'] ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <?php
                        $i++;
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if ($this->session->flashdata('resultSend')) {
    if (is_array($this->session->flashdata('resultSend'))) {
        geterror($this->session->flashdata('resultSend'));
    } else {
        geterror(lang('message_sended'));
    }
}
?>
