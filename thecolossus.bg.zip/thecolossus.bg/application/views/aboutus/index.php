<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="inner-page">
    <div class="top-bg about-us-bg">
        <h1><?= lang('about_us') ?></h1>
    </div> 
</div> 
<div class="info-part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('events') ?></h1>
                <div>
                    <?= $about_us_events ?>
                </div>
                <a href="<?= lang_url('events') ?>" class="btn btn-lg btn-red"><?= lang('see_all_events') ?></a>
            </div>
        </div>
    </div>
</div>
<div class="info-part silver">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('idea') ?></h1>
                <div>
                    <?= $idea_text ?>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="info-part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <a href="<?= lang_url('contactus') ?>" class="btn btn-lg btn-black in-about-btn"><?= lang('contact_with_us') ?></a>
                <a href="<?= lang_url('register') ?>" class="btn btn-lg btn-black in-about-btn"><?= lang('register_team_2') ?></a>
            </div>
        </div>
    </div>
</div> 