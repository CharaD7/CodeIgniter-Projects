<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="inner-page">
    <div class="top-bg register-bg">
        <h1><?= lang('login_h') ?></h1>
    </div> 
</div>
<div class="info-part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
                <h1><?= lang('login') ?></h1>
                <form method="POST" action="" class="site-form">
                    <div class="form-group"> 
                        <input type="text" name="email" value="" placeholder="<?= lang('your_email') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="password" name="password" value="" placeholder="<?= lang('your_password') ?>" class="form-control field">
                    </div> 
                    <div class="form-group"> 
                        <button type="submit" class="btn btn-lg btn-red"><?= lang('log_me') ?></button>
                    </div>
                </form> 
            </div>
        </div>
    </div>
</div> 
<?php
if ($this->session->flashdata('wrongLogin')) {
    geterror($this->session->flashdata('wrongLogin'));
}
?>