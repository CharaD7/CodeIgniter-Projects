<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div class="front-image">
    <img src="<?= base_url('attachments/frontpage/maxresdefault.jpg') ?>" class="img-responsive">
    <div class="centered">
        <h1>The Colossus</h1>
        <p><span class="red"><?= date('d F Y', $first_coming_evenet['date']) ?></span> - <?= $first_coming_evenet['destination'] ?></p>
        <span class="counter remaining"><?= lang('remaining') ?></span>
        <span id="countdown" class="counter"></span>
        <script>
            var countdown = {
                upgradeTime: <?= $first_coming_evenet['date'] - time() ?>,
                w_days: '<?= lang('days') ?>',
                w_hours: '<?= lang('hours') ?>',
                w_minutes: '<?= lang('minutes') ?>',
                w_end: '<?= lang('and') ?>',
                w_seconds: '<?= lang('seconds') ?>',
                w_today: '<?= lang('today') ?>'
            };
        </script>
    </div>
</div>
<div class="container-fluid">
    <div class="info-part">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('register_team_2') ?></h1>
                <div>
                    <?= $home_page_register_team ?>
                </div> 
                <a href="<?= lang_url('register') ?>" style="position: relative;" class="btn btn-lg btn-red relative"><?= lang('register_now') ?>
                    <img src="<?= base_url('assets/public/imgs/home-arrow-left.png') ?>" class="home-arrow-left" alt="">
                    <img src="<?= base_url('assets/public/imgs/home-arrow-right.png') ?>" class="home-arrow-right" alt="">
                </a>
            </div>
        </div>
    </div>
</div>
<div class="info-part silver">
    <h1><?= lang('location_event') ?></h1>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <p>
                    <?= $first_coming_evenet['description'] ?>
                </p>
            </div>
        </div>
    </div>
    <div id="google-map-home"></div>
    <script>
<?php $google = explode(',', $first_coming_evenet['google']); ?>
        function initMap() {
            var uluru = {lat: <?= $google[0] ?>, lng: <?= $google[1] ?>};
            var map = new google.maps.Map(document.getElementById('google-map-home'), {
                zoom: 4,
                center: uluru
            });
            var marker = new google.maps.Marker({
                position: uluru,
                map: map
            });
        }
    </script>
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAPPs6IJz-pAPimqFBoN-PoM0RNQQZKixY&callback=initMap"></script>
</div>
<div class="homeBottomImages">
    <ul>
        <?php
        foreach ($images as $image) {
            ?>
            <li>
                <img src="<?= $image ?>">
            </li>
            <?php
        }
        ?>
    </ul>
</div>
