<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<link href="<?= base_url('assets/semantic/checkbox.min.css') ?>" rel="stylesheet">
<div class="inner-page">
    <div class="top-bg register-bg">
        <h1><?= lang('register') ?></h1>
    </div> 
</div>
<div class="info-part">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
                <h1><?= lang('create_profile') ?></h1>
                <form method="POST" action="<?= lang_url('register') ?>" class="site-form">
                    <div class="form-group"> 
                        <input type="text" name="name" value="<?= trim($this->session->flashdata('name')) ?>" placeholder="<?= lang('your_name') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="text" name="family" value="<?= trim($this->session->flashdata('family')) ?>" placeholder="<?= lang('your_family') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="text" name="phone" value="<?= trim($this->session->flashdata('phone')) ?>" placeholder="<?= lang('your_phone') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="text" name="email" value="<?= trim($this->session->flashdata('email')) ?>" placeholder="<?= lang('your_email') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="password" name="password" value="<?= trim($this->session->flashdata('password')) ?>" placeholder="<?= lang('your_password') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <input type="password" name="repeat_password" value="<?= trim($this->session->flashdata('repeat_password')) ?>" placeholder="<?= lang('your_password_repeat') ?>" class="form-control field">
                    </div>
                    <div class="form-group"> 
                        <div class="ui checkbox pull-left">
                            <input id="example-id" <?= $this->session->flashdata('rules') !== null ? 'checked' : '' ?> name="rules" type="checkbox">
                            <label for="example-id"><?= lang('confirm_rules') ?></label>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="form-group"> 
                        <div style="margin-bottom: 10px;">
                            <button type="submit" class="btn btn-lg btn-red"><?= lang('register_now') ?></button>
                        </div>
                        <div>
                            <a href="<?= lang_url('login') ?>" class="btn btn-black"><?= lang('i_have_profile') ?></a>
                        </div>
                    </div>
                </form> 
            </div>
        </div>
    </div>
</div>
<div class="info-part silver">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2">
                <h1><?= lang('rules') ?></h1>
                <div>
                    <?= $text_rules ?>
                </div>
            </div>
        </div>
    </div>
</div> 
<?php
if ($this->session->flashdata('resultRegister')) {
    geterror($this->session->flashdata('resultRegister'));
}
?>