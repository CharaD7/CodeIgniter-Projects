<?php

class ContactusModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getEmails($to = 10)
    {
        $this->db->order_by('id', 'desc');
        $this->db->limit($to, 0);
        $this->db->where('deleted', 0);
        $result = $this->db->get('received_emails');
        return $result->result_array();
    }

    public function getOneEmail($id)
    {
        $this->db->where('id', $id);
        $this->db->where('deleted', 0);
        $result = $this->db->get('received_emails');
        if ($result->row_array() !== null) {
            $this->db->where('id', $id);
            $this->db->update('received_emails', array('readed' => 1));
            return $result->row_array();
        }
    }

    public function countAllEmails()
    {
        $this->db->where('deleted', 0);
        return $this->db->count_all_results('received_emails');
    }

    public function deleteEmail($id)
    {
        $this->db->where('id', $id);
        $this->db->update('received_emails', array('deleted' => 1));
    }

    public function countUnReadedEmails()
    {
        $this->db->where('deleted', 0);
        $this->db->where('readed', 0);
        return $this->db->count_all_results('received_emails');
    }

    public function getUnreadEmails($to)
    {
        $this->db->limit($to, 0);
        $this->db->where('deleted', 0);
        $this->db->where('readed', 0);
        $result = $this->db->get('received_emails');
        return $result->result_array();
    }

    public function saveSendedEmail($post)
    {
        $post['time'] = time();
        $this->db->insert('sended_emails', $post);
    }

    public function getSendedEmails($to = 10)
    {
        $this->db->order_by('id', 'desc');
        $this->db->limit($to, 0);
        $result = $this->db->get('sended_emails');
        return $result->result_array();
    }

    public function countAllSendedEmails()
    {
        return $this->db->count_all_results('sended_emails');
    }

    public function getQuestions()
    {
        $this->db->order_by('position', 'asc');
        $this->db->where('abbr', MY_DEFAULT_LANGUAGE_ABBR);
        $this->db->select('questions.id, questions.position, questions_translates.question, questions_translates.answer');
        $this->db->join('questions_translates', 'questions_translates.for_id = questions.id');
        $result = $this->db->get('questions');
        return $result->result_array();
    }

    public function addQuestion($post)
    {
        if ($post['edit'] > 0) {
            $this->db->where('id', $post['edit']);
            $this->db->update('questions', array(
                'position' => $post['position']
            ));
            $insert_id = $post['edit'];
        } else {
            $this->db->insert('questions', array(
                'position' => $post['position']
            ));
            $insert_id = $this->db->insert_id();
        }
        $this->setQuestionTranslations($post, $insert_id);
    }

    private function setQuestionTranslations($post, $insert_id)
    {
        $i = 0;
        foreach ($post['abbr'] as $abbr) {
            if ($post['edit'] > 0) {
                $this->db->where('for_id', $insert_id);
                $this->db->where('abbr', $abbr);
                $this->db->update('questions_translates', array(
                    'question' => $post['question'][$i],
                    'answer' => $post['answer'][$i]
                ));
            } else {
                $this->db->insert('questions_translates', array(
                    'question' => $post['question'][$i],
                    'answer' => $post['answer'][$i],
                    'abbr' => $abbr,
                    'for_id' => $insert_id
                ));
            }
            $i++;
        }
    }

    public function getQuestion($id)
    {
        $array = array();
        $this->db->where('id', $id);
        $result = $this->db->get('questions');
        $array = $result->row_array();

        $this->db->where('for_id', $id);
        $result = $this->db->get('questions_translates');
        foreach ($result->result_array() as $row) {
            $array['translations'][$row['abbr']] = array(
                'question' => $row['question'],
                'answer' => $row['answer']
            );
        }
        return $array;
    }

    public function deleteQuestion($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('questions');
        $this->db->where('for_id', $id);
        $this->db->delete('questions_translates');
    }

}
