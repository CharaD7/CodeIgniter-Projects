<?php

class LanguagesModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function deleteLanguage($id)
    {
        $this->db->where('id', $id);
        $result = $this->db->delete('languages');
        return $result;
    }

    public function countLangs($name = null, $abbr = null)
    {
        if ($name != null) {
            $this->db->where('name', $name);
        }
        if ($abbr != null) {
            $this->db->or_where('abbr', $abbr);
        }
        return $this->db->count_all_results('languages');
    }

    public function getLanguages()
    {
        $query = $this->db->query('SELECT * FROM languages');
        return $query;
    }

    public function setLanguage($post)
    {
        $post['name'] = strtolower($post['name']);
        $post['abbr'] = strtolower($post['abbr']);
        $result = $this->db->insert('languages', $post);
        return $result;
    }

}
