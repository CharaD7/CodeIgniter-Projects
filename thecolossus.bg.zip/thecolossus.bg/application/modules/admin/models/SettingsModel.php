<?php

class SettingsModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getValueStores()
    {
        $result = $this->db->get('value_store');
        return $result->result_array();
    }

}
