<?php

class EventsModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function addEvent($post)
    {
        if ($post['edit'] > 0) {
            $this->db->where('id', $post['edit']);
            $this->db->update('events', array(
                'date' => strtotime($post['date']),
                'image' => $post['image'],
                'google' => $post['google'],
                'num_members' => $post['num_members']
            ));
            $insert_id = $post['edit'];
        } else {
            $this->db->insert('events', array(
                'date_created' => time(),
                'date' => strtotime($post['date']),
                'image' => $post['image'],
                'google' => $post['google'],
                'num_members' => $post['num_members']
            ));
            $insert_id = $this->db->insert_id();
        }
        $this->setEventTranslations($post, $insert_id);
    }

    private function setEventTranslations($post, $insert_id)
    {
        $i = 0;
        foreach ($post['abbr'] as $abbr) {
            if ($post['edit'] > 0) {
                $this->db->where('for_id', $insert_id);
                $this->db->where('abbr', $abbr);
                $this->db->update('events_translates', array(
                    'title' => $post['title'][$i],
                    'description' => $post['description'][$i],
                    'destination' => $post['destination'][$i],
                    'description_in_users' => $post['description_in_users'][$i]
                ));
            } else {
                $this->db->insert('events_translates', array(
                    'title' => $post['title'][$i],
                    'description' => $post['description'][$i],
                    'destination' => $post['destination'][$i],
                    'description_in_users' => $post['description_in_users'][$i],
                    'abbr' => $abbr,
                    'for_id' => $insert_id
                ));
            }
            $i++;
        }
    }

    public function getEvent($id)
    {
        $array = array();
        $this->db->where('id', $id);
        $result = $this->db->get('events');
        $array = $result->row_array();

        $this->db->where('for_id', $id);
        $result = $this->db->get('events_translates');
        foreach ($result->result_array() as $row) {
            $array['translations'][$row['abbr']] = array(
                'title' => $row['title'],
                'description' => $row['description'],
                'destination' => $row['destination'],
                'description_in_users' => $row['description_in_users']
            );
        }
        return $array;
    }

    public function getEvents($limit, $page)
    {
        $this->db->select('events.id, events.date, events.date_created, events.image, events.google, events.num_members, events_translates.title, events_translates.description, events_translates.destination');
        $this->db->where('abbr', MY_DEFAULT_LANGUAGE_ABBR);
        $this->db->order_by('events.id', 'desc');
        $this->db->join('events_translates', 'for_id = events.id');
        $query = $this->db->get('events', $limit, $page);
        return $query->result_array();
    }

    public function eventsCount()
    {
        return $this->db->count_all_results('events');
    }

    public function deleteEvent($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('events');
        $this->db->where('for_id', $id);
        $this->db->delete('events_translates');
    }

}
