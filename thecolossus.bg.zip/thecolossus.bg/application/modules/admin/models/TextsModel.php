<?php

class TextsModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function addText($post)
    {
        $this->db->insert('texts', array(
            'admin_info' => $post['admin_info'],
            'my_key' => $post['my_key']
        ));
        $insert_id = $this->db->insert_id();
        $this->setTextTranslations($post, $insert_id);
    }

    private function setTextTranslations($post, $insert_id)
    {
        $i = 0;
        foreach ($post['abbr'] as $abbr) {
            $this->db->insert('texts_translates', array(
                'text' => $post['text'][$i],
                'abbr' => $abbr,
                'for_id' => $insert_id
            ));
            $i++;
        }
    }

    public function getTexts()
    {
        $array = array();
        $result = $this->db->get('texts');
        foreach ($result->result_array() as $text) {
            $this->db->where('for_id', $text['id']);
            $result1 = $this->db->get('texts_translates');
            foreach ($result1->result_array() as $row) {
                $array[$text['my_key']]['translations'][$row['abbr']] = $row['text'];
                $array[$text['my_key']]['info'] = $text['admin_info'];
                $array[$text['my_key']]['id'] = $text['id'];
            }
        }
        return $array;
    }

    public function editText($post)
    {
        $i = 0;
        foreach ($post['abbr'] as $abbr) {
            $this->db->where('for_id', $post['edit_id']);
            $this->db->where('abbr', $abbr);
            $this->db->update('texts_translates', array(
                'text' => $post['text_e'][$i]
            ));
            $i++;
        }
    }

}
