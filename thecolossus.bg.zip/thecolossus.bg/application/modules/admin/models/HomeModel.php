<?php

class HomeModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function getTotalUsers()
    {
        return $this->db->count_all_results('users');
    }

    public function getUsersForLastWeek()
    {
        $this->db->where('registered >=', strtotime("-1 week"));
        return $this->db->count_all_results('users');
    }

    public function getTotalTeamMembers()
    {
        return $this->db->count_all_results('team_members');
    }

    public function getVerifiedTeamMembers()
    {
        $this->db->where('verified >', 0);
        return $this->db->count_all_results('team_members');
    }

    public function getMonthlyRegistered()
    {
        $output = array();
        $return = $this->db->query('SELECT COUNT(id) as num, DATE_FORMAT(FROM_UNIXTIME(registered), "%c") as month, DATE_FORMAT(FROM_UNIXTIME(registered), "%Y") as year FROM users GROUP BY DATE_FORMAT(FROM_UNIXTIME(registered), "%c"), DATE_FORMAT(FROM_UNIXTIME(registered), "%Y")');
        $rows = $return->result_array();
        $months = array();
        for ($i = 1; $i <= 12; $i++) {
            $months[$i] = 0;
        }
        foreach ($rows as $row) {
            if (!isset($output[$row['year']])) {
                $output[$row['year']] = $months;
            }
            $output[$row['year']][$row['month']] = $row['num'];
        }
        return $output;
    }

}
