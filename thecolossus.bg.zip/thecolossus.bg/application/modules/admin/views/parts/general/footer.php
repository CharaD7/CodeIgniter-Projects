<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
<footer>
    <div class="pull-right">
        Developed by <a target="_blank" href="https://github.com/kirilkirkov">Kiril Kirkov</a> (<a target="_blank" href="http://eccfze.ae">ECCFZE.AE Company</a>)
    </div>
    <div class="clearfix"></div>
</footer>
</div>
</div>
<script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<script>
    var urls = {
        getMoreEmails: '<?= base_url('admin/getMoreEmails') ?>'
    };
</script>
<script src="<?= base_url('assets/admin/js/bootbox.min.js') ?>"></script>
<script src="<?= base_url('assets/admin/js/general.js') ?>"></script>
</body>
</html>