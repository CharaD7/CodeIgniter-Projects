<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= $title ?></title>
        <link href="<?= base_url('assets/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet"> 
        <link href="<?= base_url('assets/admin/css/general.css') ?>" rel="stylesheet">
        <script src="<?= base_url('assets/jquery/jquery.min.js') ?>"></script> 
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="nav-md"> 
        <div class="container body">
            <div class="main_container">
                <div class="col-md-3 left_col">
                    <div class="left_col scroll-view">
                        <div class="navbar nav_title" style="border: 0;">
                            <a href="<?= base_url('admin') ?>" class="site_title">
                                <img src="<?= base_url('assets/admin/imgs/logo.png') ?>" alt="logo">
                            </a>
                        </div>
                        <div class="clearfix"></div>
                        <div class="profile clearfix">
                            <div class="profile_pic">
                                <img src="<?= base_url($_SESSION['logged_user_info']['image']) ?>" alt="..." class="img-circle profile_img">
                            </div>
                            <div class="profile_info">
                                <span>Welcome,</span>
                                <h2><?= $_SESSION['logged_user_info']['name'] ?></h2>
                            </div>
                        </div>
                        <br />
                        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                            <div class="menu_section">
                                <h3>Private</h3>
                                <ul class="nav side-menu">
                                    <li>
                                        <a class="category"><i class="fa fa-home"></i> Home <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?= base_url('admin/home') ?>">Dashboard</a></li>
                                        </ul>
                                    </li>
                                    <li>
                                        <a class="category"><i class="fa fa-envelope-o"></i>Emails <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?= base_url('admin/sendemail') ?>">Send Email</a></li>
                                            <li><a href="<?= base_url('admin/receivedemails') ?>">Received</a></li>
                                            <li><a href="<?= base_url('admin/sendedemails') ?>">Sended</a></li>
                                        </ul>
                                    </li> 
                                </ul>
                            </div>
                            <div class="menu_section">
                                <h3>Public</h3>
                                <ul class="nav side-menu">
                                    <li>
                                        <a class="category"><i class="fa fa-clock-o"></i> Events <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?= base_url('admin/addevent') ?>">Add Event</a></li>
                                            <li><a href="<?= base_url('admin/events') ?>">Events</a></li>
                                        </ul> 
                                    </li> 
                                    <li>
                                        <a class="category"><i class="fa fa-question-circle-o"></i> FA Questions <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?= base_url('admin/addquestion') ?>">Add Question</a></li>
                                            <li><a href="<?= base_url('admin/questions') ?>">Questions</a></li>
                                        </ul> 
                                    </li>  
                                    <li><a href="<?= base_url('admin/texts') ?>"><i class="fa fa-text-width"></i> Pages Texts</a></li> 
                                </ul>
                            </div>
                            <div class="menu_section">
                                <h3>Settings</h3>
                                <ul class="nav side-menu">
                                    <li>
                                        <a class="category"><i class="fa fa-users"></i> Administrators <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?= base_url('admin/administrators') ?>">Administators list</a></li> 
                                            <li><a href="<?= base_url('admin/history') ?>">History</a></li> 
                                        </ul>
                                    </li>     
                                    <li><a href="<?= base_url('admin/languages') ?>"><i class="fa fa-globe"></i> Languages</a></li> 
                                    <li><a href="<?= base_url('admin/settings') ?>"><i class="fa fa-cog"></i> Settings</a></li> 
                                </ul>
                            </div>
                        </div>
                        <div class="sidebar-footer hidden-small">
                            <a href="<?= base_url('admin/home') ?>">
                                <span class="glyphicon glyphicon glyphicon-home" aria-hidden="true"></span>
                            </a>
                            <a href="<?= base_url('admin/settings') ?>">
                                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                            </a>
                            <a href="<?= base_url('admin/administrators?edit=' . $_SESSION['logged_user_info']['id']) ?>">
                                <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                            </a>
                            <a href="<?= base_url('admin/logout') ?>">
                                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="top_nav">
                    <div class="nav_menu">
                        <nav>
                            <div class="nav toggle">
                                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
                            </div>

                            <ul class="nav navbar-nav navbar-right">
                                <li class="">
                                    <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                                        <img src="<?= base_url($_SESSION['logged_user_info']['image']) ?>" alt=""><?= $_SESSION['logged_user_info']['name'] ?>
                                        <span class=" fa fa-angle-down"></span>
                                    </a>
                                    <ul class="dropdown-menu dropdown-usermenu pull-right">
                                        <li><a href="<?= base_url('admin/administrators?edit=' . $_SESSION['logged_user_info']['id']) ?>"> Profile</a></li>
                                        <li>
                                            <a href="<?= base_url('admin/settings') ?>">
                                                <span>Settings</span>
                                            </a>
                                        </li>
                                        <li><a href="javascript:;">Help</a></li>
                                        <li><a href="<?= base_url('admin/logout') ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                                    </ul>
                                </li>
                                <li role="presentation" class="dropdown">
                                    <a href="javascript:;" class="dropdown-toggle info-number" data-toggle="dropdown" aria-expanded="false">
                                        <i class="fa fa-envelope-o"></i>
                                        <span class="badge bg-green"><?= $numUnReadedEmails ?></span>
                                    </a>
                                    <ul id="menu1" class="dropdown-menu list-unstyled msg_list" role="menu">
                                        <?php foreach ($last4unreaded as $email) { ?>
                                            <li>
                                                <a href="<?= base_url('admin/receivedemails?showEmail=' . $email['id']) ?>">
                                                    <span>
                                                        <span><?= $email['name'] ?></span>
                                                        <span class="time"><?= date('d.m.Y', $email['time']) ?></span>
                                                    </span>
                                                    <span class="message">
                                                        <?= character_limiter(strip_tags($email['message']), 80) ?>
                                                    </span>
                                                </a>
                                            </li>
                                        <?php } ?>
                                        <li>
                                            <div class="text-center">
                                                <a href="<?= base_url('admin/receivedemails') ?>">
                                                    <strong>See All Emails</strong>
                                                    <i class="fa fa-angle-right"></i>
                                                </a>
                                            </div>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>