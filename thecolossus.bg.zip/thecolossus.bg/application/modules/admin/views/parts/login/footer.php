<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
<script src="<?= base_url('assets/jquery/jquery.min.js') ?>"></script> 
<script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script> 
</body>
</html>