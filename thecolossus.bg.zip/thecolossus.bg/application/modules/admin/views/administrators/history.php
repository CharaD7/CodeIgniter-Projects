<div class="right_col" role="main">
    <div class="row"> 
        <div class="col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Administrators history</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <?php if ($history === false) { ?>
                        <div class="alert alert-danger">History is stopped! Go to config.php and set <b>admin_history</b> to <b>TRUE</b></div>
                    <?php } ?>
                    <div class="table-responsive">
                        <table class="table table-condensed table-bordered table-striped custab">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>User</th>
                                    <th>Action</th>
                                    <th>Time</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($actions->result()) {
                                    foreach ($actions->result() as $action) {
                                        ?>
                                        <tr>
                                            <td><?= $action->user_id ?></td>
                                            <td><?= $action->username ?></td>
                                            <td><?= $action->activity ?></td>
                                            <td><?= date('Y.m.d / H.m.s', $action->time) ?></td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    <tr><td colspan="3">No history found!</td></tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                    <?= $links_pagination ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if (isset($_GET['edit'])) { ?>
    <script>
        $(document).ready(function () {
            $("#add_edit_users").modal('show');
        });
    </script>
<?php } ?>