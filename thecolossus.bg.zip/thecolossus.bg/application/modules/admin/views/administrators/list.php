<div class="right_col" role="main">
    <div class="row"> 
        <div class="col-xs-12">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Administrators</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <?php if (validation_errors()) { ?>
                        <hr>
                        <div class="alert alert-danger"><?= validation_errors() ?></div>
                        <hr>
                        <?php
                    }
                    if ($this->session->flashdata('result_add')) {
                        ?>
                        <hr>
                        <div class="alert alert-success"><?= $this->session->flashdata('result_add') ?></div>
                        <hr>
                        <?php
                    }
                    if ($this->session->flashdata('result_delete')) {
                        ?>
                        <hr>
                        <div class="alert alert-success"><?= $this->session->flashdata('result_delete') ?></div>
                        <hr>
                        <?php
                    }
                    ?>
                    <a href="javascript:void(0);" data-toggle="modal" data-target="#add_edit_users" class="btn btn-primary btn-xs pull-right" style="margin-bottom:10px;"><b>+</b> Add new user</a>
                    <?php
                    if ($users->result()) {
                        ?>
                        <table class="table table-striped custab">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Username</th> 
                                    <th>Email</th>
                                    <th>Registered</th>
                                    <th>Last login</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <?php foreach ($users->result() as $user) { ?>
                                <tr>
                                    <td><?= $user->id ?></td>
                                    <td>
                                        <?php
                                        $image = 'attachments/adminsprofileimages/' . $user->image;
                                        if (!is_file($image)) {
                                            $image = 'assets/admin/imgs/no-profile-image.jpg';
                                        }
                                        ?>
                                        <img src="<?= base_url($image) ?>" class="img-thumbnail" style="height: 50px;">
                                    </td>
                                    <td><?= $user->username ?></td> 
                                    <td><?= $user->email ?></td>
                                    <td><?= $user->registered != 0 ? date('d.m.Y - H:m:s', $user->registered) : 'Never' ?></td>
                                    <td><?= $user->last_login != 0 ? date('d.m.Y - H:m:s', $user->last_login) : 'Never' ?></td>
                                    <td class="text-center">
                                        <div>
                                            <a href="?delete=<?= $user->id ?>" class="btn-xs btn-danger confirm-delete">Delete</a>
                                            <a href="?edit=<?= $user->id ?>" class="btn-xs btn-primary">Edit</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php } ?>
                        </table>
                    <?php } else { ?>
                        <div class="clearfix"></div><hr>
                        <div class="alert alert-info">No users found!</div>
                    <?php } ?>

                    <!-- add edit users -->
                    <div class="modal fade" id="add_edit_users" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <form action="" method="POST" enctype="multipart/form-data">
                                    <div class="modal-header">
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <h4 class="modal-title" id="myModalLabel">Add Administrator</h4>
                                    </div>
                                    <div class="modal-body">
                                        <input type="hidden" name="edit" value="<?= isset($_GET['edit']) ? $_GET['edit'] : '0' ?>">
                                        <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" name="name" value="<?= isset($_POST['name']) ? $_POST['name'] : '' ?>" class="form-control" id="name">
                                        </div>
                                        <div class="form-group">
                                            <label for="username">Username</label>
                                            <input type="text" name="username" value="<?= isset($_POST['username']) ? $_POST['username'] : '' ?>" class="form-control" id="username">
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <input type="password" name="password" class="form-control" value="" id="password">
                                        </div>
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="text" name="email" class="form-control" value="<?= isset($_POST['email']) ? $_POST['email'] : '' ?>" id="email">
                                        </div>
                                        <div class="form-group">
                                            <?php
                                            if (isset($_POST['image']) && $_POST['image'] != null) {
                                                $image = 'attachments/adminsprofileimages/' . $_POST['image'];
                                                if (!file_exists($image)) {
                                                    $image = 'assets/admin/imgs/no-profile-image.jpg';
                                                }
                                                ?>
                                                <p>Current image:</p>
                                                <div>
                                                    <img src="<?= base_url($image) ?>" class="img-responsive img-thumbnail" style="max-width:300px; margin-bottom: 5px;">
                                                </div>
                                                <input type="hidden" value="<?= $_POST['image'] ?>" name="c_img">
                                            <?php }
                                            ?>
                                            <label for="userfile">Profile Image</label>
                                            <input type="file" id="userfile" name="input_file">
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                        <button type="submit" class="btn btn-primary">Save</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
    </div>
</div>
<?php if (isset($_GET['edit'])) { ?>
    <script>
        $(document).ready(function () {
            $("#add_edit_users").modal('show');
        });
    </script>
<?php } ?>