<div class="right_col" role="main">
    <div class="page-title">
        <div class="title_left">
            <h3>Settings</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <?php foreach ($value_stores as $valueStore) { ?>
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><?= $valueStore['info'] ?></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <form method="POST" action="">
                            <div class="input-group">
                                <input type="hidden" name="v_key" value="<?= $valueStore['v_key'] ?>">
                                <input class="form-control" type="text" name="value" value="<?= $valueStore['value'] ?>">
                                <span class="input-group-btn">
                                    <button class="btn btn-primary" type="submit">Save</button>
                                </span>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>