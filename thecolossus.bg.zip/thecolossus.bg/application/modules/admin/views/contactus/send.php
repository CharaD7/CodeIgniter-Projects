<div class="right_col" role="main">
    <div class="">
        <div class="page-title">
            <div class="title_left">
                <h3>Send Emails</h3>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-6 col-sm-12 col-xs-12">
                <?php
                if ($this->session->flashdata('resultSend') === false) {
                    ?>
                    <div class="alert alert-danger">Message Send Error!</div>
                <?php } elseif ($this->session->flashdata('resultSend') === true) { ?>
                    <div class="alert alert-info">Message Sended!</div>
                    <?php
                }
                ?> 
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Sender <small>info@thecolossus.bg</small></h2> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <form method="POST" action="">
                            <div class="form-group">
                                <label>To Email</label>
                                <input type="text" name="to_email" placeholder="mail@example.com" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Subject</label>
                                <input type="text" name="subject" placeholder="Why write this email" class="form-control">
                            </div>
                            <div class="form-group">
                                <label>Message</label>
                                <textarea name="message" class="form-control"></textarea>
                            </div>
                            <input type="submit" class="btn btn-primary" value="Send">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>