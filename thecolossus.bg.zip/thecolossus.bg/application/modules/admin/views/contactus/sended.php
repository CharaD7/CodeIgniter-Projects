<div class="right_col" role="main">
    <div class="">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Sended emails</h2> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content"> 
                        <div class="table-responsive">
                            <table class="table table-striped jambo_table bulk_action">
                                <thead>
                                    <tr class="headings">
                                        <th class="column-title">id</th>
                                        <th class="column-title">To Email</th>
                                        <th class="column-title">Subject</th>
                                        <th class="column-title">Message</th>
                                        <th class="column-title">Time Sended</th> 
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if (!empty($emails)) {
                                        $i = 0;
                                        foreach ($emails as $email) {
                                            ?>
                                            <tr class="<?= $i = 0 ? 'even' : 'odd' ?> pointer">
                                                <td class=" "><?= $email['id'] ?></td>
                                                <td class=" "><?= $email['to_email'] ?></td>
                                                <td class=" "><?= $email['subject'] ?></td>
                                                <td class=" "><?= $email['message'] ?></td>
                                                <td class=" "><?= date('H:m:s d.m.Y', $email['time']) ?></td>  
                                            </tr>
                                            <?php
                                            $i++;
                                            if ($i > 1) {
                                                $i = 0;
                                            }
                                        }
                                    } else {
                                        ?>
                                        <tr>
                                            <td colspan="5">No Sended Emails</td>
                                        </tr>  
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php
                    if ($countEmails > count($emails)) {
                        if (isset($_GET['limit'])) {
                            $more = (int) $_GET['limit'] + 5;
                            $limit = '?limit=' . $more;
                        } else {
                            $limit = '?limit=10';
                        }
                        ?>
                        <div class="text-center">
                            <a class="btn btn-primary" href="<?= $limit ?>">Show More <i class="fa fa-chevron-down"></i></a>
                        </div>
                    <?php }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>