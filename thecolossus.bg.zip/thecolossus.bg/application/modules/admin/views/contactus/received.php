<div class="right_col" role="main">
    <div class=""> 
        <div class="page-title">
            <div class="title_left">
                <h3>Inbox <small>received emails from contact form</small></h3>
            </div>
        </div> 
        <div class="clearfix"></div> 
        <div class="row">
            <div class="col-md-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2>Emails</h2> 
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <div class="row">
                            <div class="col-sm-3 mail_list_column">
                                <button class="btn btn-sm btn-success btn-block compose-open" type="button">COMPOSE</button>
                                <?php
                                if (!empty($emails)) {
                                    foreach ($emails as $email) {
                                        ?>
                                        <a href="?showEmail=<?= $email['id'] ?>">
                                            <div class="mail_list">
                                                <div class="left">
                                                    <i class="fa <?= $email['readed'] == 0 ? 'fa-circle' : 'fa-circle-o' ?>"></i> <i class="fa fa-edit"></i>
                                                </div>
                                                <div class="right">
                                                    <h3><?= $email['name'] ?> <small><?= date('h:m:s d.m.Y', $email['time']) ?></small></h3>
                                                    <p class="email-message-small-preview">
                                                        <?= character_limiter(strip_tags($email['message']), 120) ?>
                                                    </p>
                                                </div>
                                            </div>
                                        </a> 
                                        <?php
                                    } if ($countEmails > count($emails)) {
                                        if (isset($_GET['limit'])) {
                                            $more = (int) $_GET['limit'] + 5;
                                            $limit = '?limit=' . $more;
                                        } else {
                                            $limit = '?limit=10';
                                        }
                                        ?>
                                        <div class="text-center">
                                            <a class="btn btn-primary" href="<?= $limit ?>">Show More <i class="fa fa-chevron-down"></i></a>
                                        </div>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    No Received Messages
                                <?php } ?>
                            </div> 
                            <div class="col-sm-9 mail_view">
                                <div class="inbox-body">
                                    <?php if (isset($readEmail)) { ?>
                                        <div class="mail_heading row">
                                            <div class="col-md-8">
                                                <div class="btn-group">
                                                    <button class="btn btn-sm btn-primary compose-open" data-reply-to="<?= $readEmail['email'] ?>" type="button"><i class="fa fa-reply"></i> Reply</button> 
                                                    <button class="btn btn-sm btn-default" type="button" onclick="printEmail()"><i class="fa fa-print"></i></button>
                                                    <a href="?delete=<?= $readEmail['id'] ?>" class="btn btn-sm btn-default confirm-delete"><i class="fa fa-trash-o"></i></a>
                                                </div>
                                            </div>
                                            <div class="col-md-4 text-right">
                                                <p class="date"> <?= date('h:m:s d.m.Y', $readEmail['time']) ?></p>
                                            </div>
                                            <div class="col-md-12">
                                                <h4>Message from contact page</h4>
                                            </div>
                                        </div>
                                        <div class="sender-info">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <strong><?= $readEmail['name'] ?></strong>
                                                    <span>(<?= $readEmail['email'] ?>)</span> to
                                                    <strong>me</strong>
                                                    <a class="sender-dropdown"><i class="fa fa-chevron-down"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="view-mail" id="theEmail">
                                            <?= $readEmail['message'] ?>
                                        </div>
                                        <div class="btn-group">
                                            <button class="btn btn-sm btn-primary compose-open" type="button"><i class="fa fa-reply"></i> Reply</button>
                                            <button class="btn btn-sm btn-default" type="button" onclick="printEmail()"><i class="fa fa-print"></i></button>
                                            <a href="?delete=<?= $readEmail['id'] ?>" class="btn btn-sm btn-default confirm-delete"><i class="fa fa-trash-o"></i></a>
                                        </div>
                                    <?php } else { ?>
                                        <div class="alert alert-info">There is not selected email.</div>
                                    <?php } ?>
                                </div> 
                            </div> 
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="compose col-md-6 col-xs-12">
    <form method="POST" action="<?= base_url('admin/sendemail') ?>">
        <div class="compose-header">
            New Message
            <button type="button" class="close compose-close">
                <span>×</span>
            </button>
        </div> 
        <div class="compose-body">
            <div class="form-group">
                <label>To Email</label>
                <input type="text" name="to_email" placeholder="mail@example.com" class="form-control">
            </div>
            <div class="form-group">
                <label>Subject</label>
                <input type="text" name="subject" placeholder="Why write this email" class="form-control">
            </div>
            <div class="form-group">
                <label>Message</label>
                <textarea name="message" class="form-control"></textarea>
            </div>
        </div>
        <div class="compose-footer">
            <button class="btn btn-sm btn-success" type="submit">Send</button>
        </div>
    </form>
</div>
