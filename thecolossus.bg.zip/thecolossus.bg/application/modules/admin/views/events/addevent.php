<script src="<?= base_url('assets/ckeditor/ckeditor.js') ?>"></script>
<link rel="stylesheet" href="<?= base_url('assets/jquery-ui/jquery-ui.min.css') ?>">
<script src="<?= base_url('assets/jquery-ui/jquery-ui.min.js') ?>"></script>
<script>
    $(function () {
        $(".datepicker").datepicker({
            dateFormat: "dd.mm.yy"
        });
    });
</script>
<div class="right_col" role="main"> 
    <div class="page-title">
        <div class="title_left">
            <h3>Add Event</h3>
        </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="x_panel"> 
                <div class="x_content">
                    <form method="POST" action="" enctype="multipart/form-data">
                        <input type="hidden" name="edit" value="<?= isset($_GET['edit']) ? $_GET['edit'] : 0 ?>">
                        <input type="hidden" name="old_image" value="<?= isset($_POST['image']) ? $_POST['image'] : '' ?>">
                        <?php foreach ($languages->result() as $language) { ?>
                            <input type="hidden" name="abbr[]" value="<?= $language->abbr ?>">
                        <?php } foreach ($languages->result() as $language) { ?> 
                            <div class="form-group">
                                <label>Title (<?= ucfirst($language->name) ?><img src="<?= base_url('attachments/langflags/' . $language->flag) ?>" class="flag" alt="">)</label>
                                <input type="text" name="title[]" placeholder="" value="<?= isset($_POST['translations']) ? $_POST['translations'][$language->abbr]['title'] : '' ?>" class="form-control">
                            </div>
                        <?php } ?>
                        <div class="form-group">
                            <label>Date</label>
                            <input type="text" name="date" placeholder="" value="<?= isset($_POST['date']) ? date('d.m.Y', $_POST['date']) : '' ?>" class="form-control datepicker">
                        </div>
                        <div class="form-group">
                            <label>Google Coordinates</label>
                            <input type="text" name="google" placeholder="42.589409, 23.420391" value="<?= isset($_POST['google']) ? $_POST['google'] : '' ?>" class="form-control">
                        </div>
                        <div class="form-group">
                            <label>Num members needed for team</label>
                            <input type="text" name="num_members" placeholder="10" value="<?= isset($_POST['num_members']) ? $_POST['num_members'] : '' ?>" class="form-control">
                        </div>
                        <?php if (isset($_POST['image'])) { ?>
                            <img src="<?= base_url('attachments/eventsimages/' . $_POST['image']) ?>" alt="" style="height: 100px;">
                        <?php } ?>
                        <div class="form-group">
                            <label>Image</label>
                            <input type="file" name="input_file">
                        </div>
                        <?php foreach ($languages->result() as $language) { ?> 
                            <div class="form-group">
                                <label>Description (<?= ucfirst($language->name) ?><img src="<?= base_url('attachments/langflags/' . $language->flag) ?>" class="flag" alt="">)</label>
                                <textarea name="description[]" class="form-control"><?= isset($_POST['translations']) ? $_POST['translations'][$language->abbr]['description'] : '' ?></textarea>
                            </div>
                        <?php } foreach ($languages->result() as $language) { ?> 
                            <div class="form-group">
                                <label>Destination (<?= ucfirst($language->name) ?><img src="<?= base_url('attachments/langflags/' . $language->flag) ?>" class="flag" alt="">)</label>
                                <input type="text" name="destination[]" class="form-control" value="<?= isset($_POST['translations']) ? $_POST['translations'][$language->abbr]['destination'] : '' ?>">
                            </div>
                            <?php
                        } $i = 0;
                        foreach ($languages->result() as $language) {
                            ?> 
                            <div class="form-group">
                                <label>Destination (IN USERS PAGE) (<?= ucfirst($language->name) ?><img src="<?= base_url('attachments/langflags/' . $language->flag) ?>" class="flag" alt="">)</label>
                                <textarea name="description_in_users[]" id="d_in_u<?= $i ?>" class="form-control"><?= isset($_POST['translations']) ? $_POST['translations'][$language->abbr]['description_in_users'] : '' ?></textarea>
                            </div>
                            <script>
                                CKEDITOR.replace('d_in_u<?= $i ?>');
                            </script>
                            <?php
                            $i++;
                        }
                        ?>
                        <input type="submit" class="btn btn-primary" value="Save">
                        <?php if (isset($_GET['edit'])) { ?>
                            <a class="btn btn-default" href="<?= base_url('admin/events') ?>">Cancel</a>
                        <?php } ?>
                    </form>
                </div>
            </div>
        </div>
    </div> 
</div>