<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Administrators extends ADMIN_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('AdministratorsModel');
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Administrators';
        if (isset($_GET['delete'])) {
            $result = $this->AdministratorsModel->deleteAdminUser($_GET['delete']);
            if ($result == true) {
                $this->saveHistory('Delete user id - ' . $_GET['delete']);
                $this->session->set_flashdata('result_delete', 'User is deleted!');
            } else {
                $this->session->set_flashdata('result_delete', 'Problem with user delete!');
            }
            redirect('admin/administrators');
        }
        if (isset($_GET['edit']) && !isset($_POST['username'])) {
            $_POST = $this->AdministratorsModel->getAdminUsers($_GET['edit']);
        }
        $data['users'] = $this->AdministratorsModel->getAdminUsers();
        $this->form_validation->set_rules('username', 'User', 'trim|required');
        if (isset($_POST['edit']) && $_POST['edit'] == 0) {
            $this->form_validation->set_rules('password', 'Password', 'trim|required');
        }
        if ($this->form_validation->run($this)) {
            $_POST['image'] = uploader('./attachments/adminsprofileimages/');
            if ($_POST['image'] == false) {
                $_POST['image'] = $_POST['c_img'];
            }
            unset($_POST['c_img']);
            $result = $this->AdministratorsModel->setAdminUser($_POST);
            if ($result === true) {
                $this->session->set_flashdata('result_add', 'User is added!');
                $this->saveHistory('Create admin user - ' . $_POST['username']);
            } else {
                $this->session->set_flashdata('result_add', 'Problem with user add!');
                $this->saveHistory('Cant add admin user');
            }
            redirect('admin/administrators');
        }
        $this->render('administrators/list', $head, $data);
        $this->saveHistory('Go to administrators page');
    }

}
