<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Home extends ADMIN_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('HomeModel');
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Home';
        $data['totalUsers'] = $this->HomeModel->getTotalUsers();
        $data['usersForLastWeek'] = $this->HomeModel->getUsersForLastWeek();
        $data['teamMembers'] = $this->HomeModel->getTotalTeamMembers();
        $data['verifiedMembers'] = $this->HomeModel->getVerifiedTeamMembers();
        $data['monthly'] = $this->HomeModel->getVerifiedTeamMembers();
        $data['monthlyRegistered'] = $this->HomeModel->getMonthlyRegistered();
        $this->render('home/index', $head, $data);
        $this->saveHistory('Go to home page');
    }

}
