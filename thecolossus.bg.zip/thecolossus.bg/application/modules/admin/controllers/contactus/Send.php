<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Send extends ADMIN_Controller
{

    private $siteEmail;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('ContactusModel');
        $this->siteEmail = $this->PublicModel->getOneValueStore('_siteEmail');
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Send Email';
        if (isset($_POST['to_email'])) {
            $result = $this->sendEmail();
            $this->session->set_flashdata('resultSend', $result);
            redirect('admin/sendemail');
        }
        $this->render('contactus/send', $head, $data);
        $this->saveHistory('Go to send email');
    }

    private function sendEmail()
    {
        $this->load->library('email');

        $this->email->from($this->siteEmail, 'THE COLOSSUS');
        $this->email->to($_POST['to_email']);

        $this->email->subject($_POST['subject']);
        $this->email->message($_POST['message']);

        $result = $this->email->send();

        $this->saveSendedToDb();
        $this->saveHistory('Send email to ' . $_POST['to_email']);

        return $result;
    }

    private function saveSendedToDb()
    {
        $this->ContactusModel->saveSendedEmail($_POST);
    }

}
