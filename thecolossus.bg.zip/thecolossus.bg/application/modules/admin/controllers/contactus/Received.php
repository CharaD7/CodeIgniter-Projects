<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Received extends ADMIN_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('ContactusModel');
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Received Emails';
        $limit = 10;
        if (isset($_GET['limit'])) {
            $limit = $_GET['limit'];
        }
        $data['emails'] = $this->ContactusModel->getEmails($limit);
        if (isset($_GET['showEmail'])) {
            $data['readEmail'] = $this->ContactusModel->getOneEmail($_GET['showEmail']);
        }
        if (isset($_GET['delete'])) {
            $this->ContactusModel->deleteEmail($_GET['delete']);
            redirect('admin/receivedemails');
        }
        $data['countEmails'] = $this->ContactusModel->countAllEmails();
        $this->render('contactus/received', $head, $data);
        $this->saveHistory('Go to received emails');
    }

}
