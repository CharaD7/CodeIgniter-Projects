<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Sended extends ADMIN_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('ContactusModel');
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Sended Emails';
        $limit = 10;
        if (isset($_GET['limit'])) {
            $limit = $_GET['limit'];
        }
        $data['countEmails'] = $this->ContactusModel->countAllSendedEmails();
        $data['emails'] = $this->ContactusModel->getSendedEmails($limit);
        $this->render('contactus/sended', $head, $data);
        $this->saveHistory('Go to sended emails');
    }

}
