<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Addevent extends ADMIN_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model(array('EventsModel', 'LanguagesModel'));
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Add Event';
        $data['languages'] = $this->LanguagesModel->getLanguages();
        if (isset($_POST['title'])) {
            $this->addEvent();
        }
        if (isset($_GET['edit'])) {
            $this->getEvent();
        }
        $this->render('events/addevent', $head, $data);
        $this->saveHistory('Go to add event');
    }

    private function addEvent()
    {
        $_POST['image'] = uploader('./attachments/eventsimages/');
        if ($_POST['image'] == false) {
            $_POST['image'] = $_POST['old_image'];
        }
        $this->EventsModel->addEvent($_POST);
        redirect('admin/events');
    }

    private function getEvent()
    {
        $_POST = $this->EventsModel->getEvent($_GET['edit']);
    }

}
