<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Events extends ADMIN_Controller
{

    private $num_rows = 20;

    public function __construct()
    {
        parent::__construct();
        $this->load->model('EventsModel');
    }

    public function index($page = 0)
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Events';
        if (isset($_GET['delete'])) {
            $this->EventsModel->deleteEvent($_GET['delete']);
        }
        $data['events'] = $this->EventsModel->getEvents($this->num_rows, $page);
        $rowscount = $this->EventsModel->eventsCount();
        $data['links_pagination'] = pagination('admin/events', $rowscount, $this->num_rows, 3);
        $this->render('events/events', $head, $data);
        $this->saveHistory('Go to events');
    }

}
