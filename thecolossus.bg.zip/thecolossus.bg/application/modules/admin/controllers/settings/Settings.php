<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Settings extends ADMIN_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('SettingsModel');
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = 'Administration - Settings';
        if (isset($_POST['v_key'])) {
            $this->GeneralAdminModel->setValueStore($_POST);
            redirect('admin/settings');
        }
        $data['value_stores'] = $this->SettingsModel->getValueStores();
        $this->render('settings/index', $head, $data);
        $this->saveHistory('Go to settings page');
    }

}
