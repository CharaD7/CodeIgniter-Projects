<?php

class UsersModel extends CI_Model
{

    public function __construct()
    {
        parent::__construct();
    }

    public function checkHaveITeam($user_id, $event_id)
    {
        $this->db->where('for_event', $event_id);
        $this->db->where('for_user', $user_id);
        return $this->db->count_all_results('teams');
    }

    public function countEvents($event_id)
    {
        $this->db->where('id', $event_id);
        return $this->db->count_all_results('events');
    }

    public function addTeam($post)
    {
        $this->db->insert('teams', array(
            'name' => htmlspecialchars($post['team_name']),
            'image' => $post['image'],
            'time_created' => time(),
            'for_user' => $_SESSION['user_login']['id'],
            'for_event' => $post['for_event']
        ));
    }

    public function getMyTeam($user_id, $event_id)
    {
        $this->db->where('for_event', $event_id);
        $this->db->where('for_user', $user_id);
        $this->db->limit(1);
        $result = $this->db->get('teams');
        return $result->row_array();
    }

    public function getTeamMembers($team_id)
    {
        $this->db->where('for_team', $team_id);
        $result = $this->db->get('team_members');
        return $result->result_array();
    }

    public function deleteTeam($team_id, $created_from)
    {
        $this->db->trans_start();
        $this->db->query('DELETE FROM teams WHERE id =' . $this->db->escape($team_id) . ' AND for_user = ' . $this->db->escape($created_from));
        $this->db->query('DELETE FROM team_members WHERE for_team =' . $this->db->escape($team_id) . ' AND created_from = ' . $this->db->escape($created_from));
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE) {
            return false;
        }
        return true;
    }

    public function editTeam($post, $user_id)
    {
        $this->db->where('for_user', $user_id);
        $this->db->where('id', $post['team_id']);
        unset($post['team_id'], $post['n_team_name']);
        $post['name'] = htmlspecialchars($post['name']);
        $this->db->update('teams', $post);
    }

    public function getCommingEvents()
    {
        $this->db->select('events.id, events.date, events_translates.title');
        $this->db->order_by('date', 'asc');
        $this->db->where('date >=', time());
        $this->db->where('events_translates.abbr', MY_LANGUAGE_ABBR);
        $this->db->join('events_translates', 'events.id = events_translates.for_id');
        $result = $this->db->get('events');
        return $result->result_array();
    }

    public function getEventInfo($event_id)
    {
        $this->db->select('events.*, events_translates.title, events_translates.description, events_translates.description_in_users, events_translates.destination');
        $this->db->where('events.id', $event_id);
        $this->db->where('events_translates.abbr', MY_LANGUAGE_ABBR);
        $this->db->join('events_translates', 'events.id = events_translates.for_id');
        $result = $this->db->get('events');
        return $result->row_array();
    }

    public function checkEmailFree($email)
    {
        $this->db->where('email', $email);
        $num = $this->db->count_all_results('team_members');

        $this->db->where('email', $email);
        $num1 = $this->db->count_all_results('users');
        return $num + $num1;
    }

    public function addMember($post)
    {
        $date_added = time();
        $this->db->insert('team_members', array(
            'email' => $post['member_email'],
            'date_added' => $date_added,
            'for_team' => $post['team_id'],
            'hash' => md5($post['member_email'] . $date_added),
            'created_from' => $post['created_from']
        ));
    }

    public function deleteMember($id, $created_from)
    {
        $this->db->where('created_from', $created_from);
        $this->db->where('id', $id);
        $this->db->delete('team_members');
    }

    public function editUser($post, $user_id)
    {
        if (isset($post['password'])) {
            $post['password'] = md5($post['password']);
        }
        $this->db->where('id', $user_id);
        $this->db->update('users', $post);
    }

    public function getAllMyTeams($user_id)
    {
        $this->db->where('for_user', $user_id);
        $result = $this->db->get('teams');
        return $result->result_array();
    }

}
