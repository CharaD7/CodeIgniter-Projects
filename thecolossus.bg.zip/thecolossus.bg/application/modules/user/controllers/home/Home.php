<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Home extends USER_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = '';
        $data['events'] = $this->UsersModel->getCommingEvents();
        $this->render('home/index', $head, $data);
    }

    public function logout()
    {
        unset($_SESSION['user_login']);
        redirect(base_url());
    }

    public function loadeventinfo()
    {
        $result = $this->UsersModel->getEventInfo($_POST['event_id']);
        echo json_encode($result);
    }

}
