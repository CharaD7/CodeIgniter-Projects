<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Edit extends USER_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index()
    {
        $data = array();
        $head = array();
        $head['title'] = '';
        if (isset($_POST['name'])) {
            $result = $this->updateProfile();
            $this->session->set_flashdata('editResult', $result);
            redirect(lang_url('user/edit'));
        }
        $this->render('edit/index', $head, $data);
    }

    private function updateProfile()
    {
        $errors = array();
        if (mb_strlen(trim($_POST['name'])) == 0) {
            $errors[] = lang('empty_name');
        }
        if (mb_strlen(trim($_POST['family'])) == 0) {
            $errors[] = lang('empty_family');
        }
        if (mb_strlen(trim($_POST['phone'])) == 0) {
            $errors[] = lang('empty_phone');
        }
        if (mb_strlen(trim($_POST['password'])) != 0) {
            if ($_POST['repeat_password'] != $_POST['password']) {
                $errors[] = lang('passwords_dont_mutch');
            } else {
                unset($_POST['repeat_password']);
            }
        } else {
            unset($_POST['repeat_password'], $_POST['password']);
        }
        $_POST['image'] = uploader('./attachments/usersimages/');
        if ($_POST['image'] == false) {
            unset($_POST['image']);
        }
        if (!empty($errors)) {
            return $errors;
        } else {
            $this->UsersModel->editUser($_POST, $_SESSION['user_login']['id']);
            foreach ($_POST as $key => $val) {
                $_SESSION['user_login'][$key] = $val;
            }
            return lang('success_edit_profile');
        }
    }

}
