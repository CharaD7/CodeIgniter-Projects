<?php

/*
 * @Author:    Kiril Kirkov
 *  Github:    https://github.com/kirilkirkov
 */
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class Myteam extends USER_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function index($event_id)
    {
        if ($event_id == null) {
            show_404();
        }
        $num_events = $this->UsersModel->countEvents($event_id);
        if ($num_events == 0) {
            show_404();
        }
        $data = array();
        $head = array();
        $head['title'] = '';
        if (isset($_POST['team_name'])) {
            $result = $this->addTeam();
            if (is_array($result)) {
                $this->session->set_flashdata('errorAddTeam', $result);
            }
            redirect(lang_url('user/myteam/' . $event_id));
        }
        if (isset($_GET['delete_team'])) {
            $message = $this->deleteTeam();
            $this->session->set_flashdata('teamDelete', $message);
            redirect(lang_url('user/myteam/' . $event_id));
        }
        if (isset($_POST['n_team_name'])) {
            $this->editTeam();
            redirect(lang_url('user/myteam/' . $event_id));
        }
        if (isset($_POST['member_email'])) {
            $result = $this->addMember();
            $this->session->set_flashdata('addMember', $result);
            redirect(lang_url('user/myteam/' . $event_id));
        }
        if (isset($_GET['delete_member'])) {
            $this->deleteMember();
            redirect(lang_url('user/myteam/' . $event_id));
        }
        $data['haveATeam'] = $this->UsersModel->checkHaveITeam($_SESSION['user_login']['id'], $event_id);
        if ($data['haveATeam'] > 0) {
            $data['myTeam'] = $this->UsersModel->getMyTeam($_SESSION['user_login']['id'], $event_id);
            $data['myTeamMembers'] = $this->UsersModel->getTeamMembers($data['myTeam']['id']);
        }
        $data['event_id'] = $event_id;
        $data['eventInfo'] = $this->UsersModel->getEventInfo($event_id);
        $this->render('myteam/index', $head, $data);
    }

    private function addTeam()
    {
        $errors = array();
        $_POST['image'] = uploader('./attachments/teamslogos/');
        if (mb_strlen(trim($_POST['team_name'])) == 0) {
            $errors[] = lang('error_team_name_empty');
        }
        if (empty($errors)) {
            $this->UsersModel->addTeam($_POST);
            return true;
        } else {
            return $errors;
        }
    }

    private function deleteTeam()
    {
        $result = $this->UsersModel->deleteTeam($_GET['delete_team'], $_SESSION['user_login']['id']);
        if ($result === false) {
            log_message('error', 'User with ID: ' . $_SESSION['user_login']['id'] . ' cant delete team with ID: ' . $_GET['delete_team']);
            $message = lang('team_delete_error');
        } else {
            $message = lang('team_delete_okey');
        }
        return $message;
    }

    private function editTeam()
    {
        $newImage = uploader('./attachments/teamslogos/');
        if ($newImage != false) {
            $_POST['image'] = $newImage;
        }
        $_POST['name'] = $_POST['n_team_name'];
        if (mb_strlen(trim($_POST['name'])) == 0) {
            unset($_POST['name']);
        }
        $this->UsersModel->editTeam($_POST, $_SESSION['user_login']['id']);
    }

    private function addMember()
    {
        $errors = array();
        if (!filter_var($_POST['member_email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = lang('invalid_email');
        }
        $num_emails = $this->UsersModel->checkEmailFree($_POST['member_email']);
        if ($num_emails > 0) {
            $errors[] = lang('email_member_taken');
        }
        if (empty($errors)) {
            $_POST['created_from'] = $_SESSION['user_login']['id'];
            $this->UsersModel->addMember($_POST);
            return true;
        } else {
            return $errors;
        }
    }

    private function deleteMember()
    {
        $this->UsersModel->deleteMember($_GET['delete_member'], $_SESSION['user_login']['id']);
    }

}
