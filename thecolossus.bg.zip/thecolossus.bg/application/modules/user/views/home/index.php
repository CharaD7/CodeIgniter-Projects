<link rel="stylesheet" href="<?= base_url('assets/user/js/fullcalendar-3.3.1/fullcalendar.min.css') ?>" />
<div class="main">
    <div class="container"> 
        <div class="row">
            <div class="col-sm-12">
                <div class="user-panel">
                    <div class="panel-header"> 
                        <h3><i class="fa fa-calendar-check-o" aria-hidden="true"></i> <?= lang('comming_events') ?></h3>
                    </div>
                    <div class="panel-body">
                        <div id='calendar'></div>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</div>
<!-- Modal Event -->
<div class="modal fade" id="modalEventPreview" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel"><?= lang('event_preview') ?></h4>
            </div>
            <div class="modal-body">
                <div class="text-center event-load-gif" style="display: none;">
                    <img src="<?= base_url('assets/user/imgs/loading_spinner.gif') ?>" style="height: 80px;" alt="">
                </div>
                <div class="event-info" style="display: none;">
                    <h1></h1>
                    <div class="dest-container">
                        <img src="<?= base_url('assets/user/imgs/google-map-icon.png') ?>" alt="google map">
                        <span class="destination"></span>
                    </div>
                    <a href="" class="btn-special"><?= lang('register_team_for_this_event') ?></a>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?= lang('close') ?></button> 
            </div>
        </div>
    </div>
</div>
<script src="<?= base_url('assets/user/js/fullcalendar-3.3.1/lib/moment.min.js') ?>"></script>
<script src="<?= base_url('assets/user/js/fullcalendar-3.3.1/fullcalendar.min.js') ?>"></script>
<script type="text/javascript">
    $(document).ready(function () {
        $('#calendar').fullCalendar({
        events: [
        {
<?php foreach ($events as $event) { ?>
            id: '<?= $event['id'] ?>',
                    title: '<?= $event['title'] ?>',
                    start: '<?= date('Y-m-d', $event['date']) ?>'
<?php } ?>
        }
        ],
        eventClick: function (calEvent, jsEvent, view) {
            $('.event-load-gif').show();
            $('#modalEventPreview').modal('show');
            $.ajax({
                method: "POST",
                url: "<?= lang_url('loadeventinfo') ?>",
                dataType: 'JSON',
                data: {event_id: calEvent.id}
            }).done(function (data) {
                $('.event-load-gif').hide();
                $('.event-info').show();
                $('.event-info h1').text(data.title);
                $('.event-info .destination').text(data.destination);
                $('.event-info a').attr('href', '<?= lang_url('user/myteam/') ?>' + data.id);
            });
            }
        }
        );
    });
</script>