<div class="main">
    <div class="container">
        <div class="user-panel">
            <div class="panel-header"> 
                <h3><i class="fa fa-pencil" aria-hidden="true"></i> <?= lang('user_edit_title') ?></h3>
            </div>
            <div class="panel-body"> 
                <div class="row">
                    <div class="col-md-4 col-sm-6"> 
                        <form method="POST" action="" enctype="multipart/form-data">
                            <div class="form-group"> 
                                <input type="text" name="name" value="<?= $_SESSION['user_login']['name'] ?>" placeholder="<?= lang('your_name') ?>" class="form-control field">
                            </div>
                            <div class="form-group"> 
                                <input type="text" name="family" value="<?= $_SESSION['user_login']['family'] ?>" placeholder="<?= lang('your_family') ?>" class="form-control field">
                            </div>
                            <div class="form-group"> 
                                <input type="text" name="phone" value="<?= $_SESSION['user_login']['phone'] ?>" placeholder="<?= lang('your_phone') ?>" class="form-control field">
                            </div> 
                            <div class="form-group"> 
                                <input type="password" name="password" value="" placeholder="<?= lang('your_password') ?>" class="form-control field">
                            </div>
                            <div class="form-group"> 
                                <input type="password" name="repeat_password" value="" placeholder="<?= lang('your_password_repeat') ?>" class="form-control field">
                            </div>
                            <?php
                            $image = base_url('assets/user/imgs/defaultProfilePic.png');
                            if ($_SESSION['user_login']['image'] != null && $_SESSION['user_login']['image'] != false && is_file('attachments/usersimages/' . $_SESSION['user_login']['image'])) {
                                $image = base_url('attachments/usersimages/' . $_SESSION['user_login']['image']);
                            }
                            ?>
                            <div class="form-group">  
                                <label><?= lang('my_profile_image') ?></label>
                                <img src="<?= $image ?>" class="img-responsive" alt="Profile Image">
                                <div>
                                    <input type="file" name="input_file">
                                </div>
                            </div>
                            <div class="form-group">  
                                <button type="submit" class="btn-special"><?= lang('edit_me') ?></button> 
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if ($this->session->flashdata('editResult')) {
    geterror($this->session->flashdata('editResult'));
}
?>