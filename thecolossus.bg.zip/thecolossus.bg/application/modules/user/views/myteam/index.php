<div class="main my-team">
    <div class="container"> 
        <div class="user-panel">
            <div class="panel-header"> 
                <h3><i class="fa fa-users" aria-hidden="true"></i> <?= lang('team_manage') . $eventInfo['title'] ?></h3>
            </div>
            <div class="panel-body">
                <?php if ($haveATeam == 0) { ?>
                    <div class="alert alert-info"><?= lang('you_dont_have_team') ?></div>
                    <h1><?= lang('team_creating') ?></h1>
                    <form action="" method="post" class="form-horizontal" enctype="multipart/form-data">
                        <input type="hidden" name="for_event" value="<?= $event_id ?>">
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="tname"><?= lang('team_name') ?>:</label>
                            <div class="col-sm-10">
                                <input type="text" name="team_name" class="form-control" id="tname" placeholder="">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="control-label col-sm-2" for="tlogo"><?= lang('team_logo') ?>:</label>
                            <div class="col-sm-10">
                                <input type="file" name="input_file" id="tlogo">
                            </div>
                        </div> 
                        <div class="form-group">
                            <div class="col-sm-offset-2 col-sm-10">
                                <button type="submit" class="btn-special"><?= lang('team_create') ?></button>
                            </div>
                        </div>
                    </form>
                <?php } else {
                    ?> 
                    <div class="payment-status">
                        <a href="" class="btn-special btn-danger">
                            <i class="fa fa-credit-card" aria-hidden="true"></i>
                            <?= lang('no_payment') ?>
                        </a>
                    </div>
                    <div class="row row-team-profile">
                        <div class="col-sm-6 col-md-4">
                            <div class="team-profile">
                                <?php
                                $image = base_url('assets/user/imgs/noteamimage.png');
                                if ($myTeam['image'] != null && $myTeam['image'] != false && is_file('attachments/teamslogos/' . $myTeam['image'])) {
                                    $image = base_url('attachments/teamslogos/' . $myTeam['image']);
                                }
                                ?>
                                <img src="<?= $image ?>" class="img-thumbnail" alt="No Team Image">
                                <h2><?= $myTeam['name'] ?><sup><?= lang('team_team') ?></sup></h2>
                            </div>
                            <a href="?delete_team=<?= $myTeam['id'] ?>" class="btn-special btn-danger team-edit confirm-delete" data-my-text="<?= lang('delete_team_sure') ?>">
                                <?= lang('delete_team') ?>
                            </a>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#editTeam" class="btn-special team-edit">
                                <?= lang('edit_team') ?>
                            </a>
                        </div>
                        <div class="col-sm-6 col-md-8">
                            <div class="myTeamText">
                                <?= $eventInfo['description_in_users'] ?>
                            </div>
                        </div>
                    </div>
                    <?php
                    if (empty($myTeamMembers)) {
                        ?>  
                        <div class="alert alert-info"><?= lang('you_dont_have_members') ?></div>
                        <div class="text-center">
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#addMember" class="btn-special"><b><?= lang('create_first_member') ?>!</b></a>
                        </div>
                    <?php } else {
                        ?> 
                        <hr>
                        <?php
                        if (count($myTeamMembers) < $eventInfo['num_members'] - 1) {
                            $need_more = $eventInfo['num_members'] - count($myTeamMembers) - 1;
                            ?>
                            <div class="alert alert-danger"><img src="<?= base_url('assets/user/imgs/warning-ic.png') ?>" style="margin-right: 10px;" alt=""><?= str_replace('%num%', $need_more, lang('no_enought_members')) ?></div>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#addMember" class="btn-special"><b><?= lang('add_member') ?>!</b></a>
                        <?php } else { ?>
                            <div class="your-team-label"><?= lang('your_team_label') ?></div>
                        <?php } ?>
                        <div class="row">
                            <?php
                            foreach ($myTeamMembers as $member) {
                                $image = base_url('assets/user/imgs/defaultProfilePic.png');
                                if ($member['image'] != null && $member['image'] != false && is_file('attachments/membersimages/' . $member['image'])) {
                                    $image = base_url('attachments/membersimages/' . $member['image']);
                                }
                                ?>
                                <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 profile">
                                    <div class="img-box">
                                        <img src="<?= $image ?>" class="img-responsive img-thumbnail" alt="not profile">
                                        <?php if ($member['verified'] == false) { ?>
                                            <div class="not-verified">
                                                <img src="<?= base_url('assets/user/imgs/notok.png') ?>" alt="Not Verified"> 
                                                <?= lang('not_verified') ?>
                                            </div>
                                        <?php } else { ?>
                                            <div class="verified">
                                                <img src="<?= base_url('assets/user/imgs/ok.png') ?>" alt="Verified"> 
                                                <?= lang('verified') ?>
                                            </div>
                                        <?php } ?>
                                    </div>
                                    <?php if ($member['verified'] == true) { ?>
                                        <h1><?= $member['name'] . ' ' . $member['family'] ?></h1>
                                        <div class="part"><i class="fa fa-clock-o" aria-hidden="true"></i> <?= lang('date_verified') . ' ' . date('d.m.Y h:m:s', $member['date_verified']) ?></div>
                                        <div class="part"><i class="fa fa-envelope-o" aria-hidden="true"></i> <?= $member['email'] ?></div>
                                    <?php } ?>
                                    <div class="verify-link">
                                        <span><i class="fa fa-link" aria-hidden="true"></i> <?= lang('verify_link') ?></span>
                                        <a href="<?= lang_url('verify/' . $member['hash']) ?>" target="_blank">
                                            <?= lang_url('verify/' . $member['hash']) ?>
                                        </a>
                                    </div> 
                                    <a href="?delete_member=<?= $member['id'] ?>" class="btn-special btn-danger confirm-delete" data-my-text="<?= lang('delete_member_sure') ?>"><?= lang('delete_member') ?></a>
                                </div> 
                            <?php } ?>
                        </div>
                        <?php
                    }
                }
                ?> 
            </div>
        </div>
    </div>
</div>
<!-- Modal Edit Team -->
<div class="modal fade" id="editTeam" tabindex="-1" role="dialog" aria-labelledby="Edit Team">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?= lang('edit_team') ?></h4>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger" id="alertEdit"></div>
                <form action="" id="teamEditForm" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="team_id" value="<?= $myTeam['id'] ?>">
                    <input type="hidden" name="for_event" value="<?= $event_id ?>">
                    <div class="form-group">
                        <label><?= lang('team_name') ?>:</label>
                        <input type="text" name="n_team_name" value="" class="form-control">
                    </div>
                    <div class="form-group">
                        <label><?= lang('team_logo') ?>:</label>
                        <input type="file" name="input_file">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?= lang('close') ?></button>
                <button type="button" class="btn btn-primary" onclick="editTeam()"><?= lang('save_changes') ?></button>
            </div>
        </div>
    </div>
</div>
<!-- Modal Add Member -->
<div class="modal fade" id="addMember" tabindex="-1" role="dialog" aria-labelledby="Add Member">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title"><?= lang('add_member') ?></h4>
            </div>
            <div class="modal-body">
                <div class="alert alert-danger" id="alertInvalidEmail"></div>
                <form method="POST" id="addMemberForm" action="">
                    <input type="hidden" name="team_id" value="<?= $myTeam['id'] ?>">
                    <div class="form-group">
                        <label><?= lang('member_email') ?>:</label>
                        <input type="text" name="member_email" placeholder="example@domain.com" value="" class="form-control">
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal"><?= lang('close') ?></button>
                <button type="button" class="btn btn-primary" onclick="addMember()"><?= lang('add_the_member') ?></button>
            </div>
        </div>
    </div>
</div>
<?php
if ($this->session->flashdata('errorAddTeam')) {
    geterror($this->session->flashdata('errorAddTeam'));
}
if ($this->session->flashdata('teamDelete')) {
    geterror($this->session->flashdata('teamDelete'));
}
if (is_array($this->session->flashdata('addMember'))) {
    geterror($this->session->flashdata('addMember'));
}
?>
<script src="<?= base_url('assets/admin/js/bootbox.min.js') ?>"></script>
<script src="<?= base_url('assets/jquery-plugins/jquery.eqheight.js') ?>"></script>
<script type="text/javascript">
$(document).ready(function () {
    $(".row").eqHeight(".profile");
});
</script>