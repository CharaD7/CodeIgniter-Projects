<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="<?= MY_LANGUAGE_ABBR ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= $title ?></title>
        <link href="<?= base_url('assets/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet">
        <link href="<?= base_url('assets/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet"> 
        <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Open+Sans:400italic,600italic,400,600">
        <link href="<?= base_url('assets/user/css/general.css') ?>" rel="stylesheet">
        <script src="<?= base_url('assets/jquery/jquery.min.js') ?>"></script> 
        <script src="<?= base_url('loadlanguage/all.js') ?>"></script>
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body>
        <div id="wrapper">
            <div id="content">
                <div class="top-nav">
                    <div class="container">
                        <a href="<?= lang_url('user') ?>" class="brand">
                            <img src="<?= base_url('assets/public/imgs/logo.png') ?>" alt="">
                        </a>
                        <a href="<?= lang_url() ?>" class="link-right"><i class="fa fa-sign-out" aria-hidden="true"></i><?= lang('back_to_site') ?></a>
                        <a href="<?= lang_url('contactus') ?>" class="link-right"><i class="fa fa-bug" aria-hidden="true"></i><?= lang('have_a_problem') ?></a>
                        <div class="dropdown dropdown-right">
                            <a class="dropdown-toggle" type="button" data-toggle="dropdown">
                                <i class="fa fa-cog" aria-hidden="true"></i> <?= lang('account') ?>
                                <span class="caret"></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-right">
                                <li><a href="<?= lang_url('user/edit') ?>"><?= lang('edit_user') ?></a></li> 
                                <li><a href="<?= base_url('user/logout') ?>"><?= lang('logout') ?></a></li> 
                            </ul>
                        </div> 
                    </div>
                </div>
                <nav class="navbar navbar-user">
                    <div class="container">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                                <span class="sr-only">Toggle navigation</span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button> 
                            <a class="visible-xs navbar-brand" href="#"><?= lang('menu') ?></a>
                        </div>
                        <div id="navbar" class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li <?= uri_string() == 'user' || uri_string() == MY_LANGUAGE_ABBR . '/user' ? 'class="active"' : '' ?>>
                                    <a href="<?= lang_url('user') ?>">
                                        <i class="fa fa-tachometer" aria-hidden="true"></i>
                                        <span><?= lang('users_home') ?></span>
                                    </a>
                                </li> 
                                <li <?= strpos(uri_string(), 'myteam') ? 'class="active"' : '' ?>>
                                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-users" aria-hidden="true"></i>
                                        <span><?= lang('my_team') ?></span>
                                    </a>
                                    <ul class="dropdown-menu">
                                        <li class="dropdown-header"><?= lang('choose_event') ?> <i class="fa fa-level-down" aria-hidden="true"></i></li>
                                        <?php foreach ($events as $event) { ?>
                                            <li><a href="<?= lang_url('user/myteam/' . $event['id']) ?>"><?= $event['title'] ?></a></li>
                                        <?php } ?>
                                    </ul>
                                </li> 
                                <?php /* ?>
                                  <li>
                                  <a href="#">
                                  <i class="fa fa-cc-visa" aria-hidden="true"></i>
                                  <span><?= lang('payment') ?></span>
                                  </a>
                                  </li>
                                 * 
                                 */ ?>
                                <li>
                                    <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown">
                                        <i class="fa fa-id-card-o" aria-hidden="true"></i>
                                        <span><?= lang('team_card') ?></span>
                                    </a>
                                    <?php
                                    if (!empty($allmyteams)) {
                                        $parse = parse_url(base_url());
                                        ?>
                                        <ul class="dropdown-menu">
                                            <?php foreach ($allmyteams as $_myteam) { ?>
                                                <li><a href="<?= 'http://team-' . $_myteam['id'] . '.' . $parse['host'] ?>"><?= $_myteam['name'] ?></a></li>
                                            <?php } ?>
                                        </ul>
                                    <?php } ?>
                                </li> 
                            </ul> 
                            <ul class="nav navbar-nav navbar-right hidden-xs">
                                <?php
                                $image = base_url('assets/user/imgs/defaultProfilePic.png');
                                if ($_SESSION['user_login']['image'] != null && $_SESSION['user_login']['image'] != false && is_file('attachments/usersimages/' . $_SESSION['user_login']['image'])) {
                                    $image = base_url('attachments/usersimages/' . $_SESSION['user_login']['image']);
                                }
                                ?>
                                <li><img src="<?= $image ?>" alt="no profile"> <?= $_SESSION['user_login']['name'] ?> <?= $_SESSION['user_login']['family'] ?></li>
                            </ul>
                        </div> 
                    </div> 
                </nav>
