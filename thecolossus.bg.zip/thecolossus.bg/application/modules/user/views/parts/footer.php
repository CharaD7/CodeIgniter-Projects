<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?> 
<div class="footer">
    <div class="extra">
        <div class="extra-inner">
            <div class="container">
                <div class="row">
                    <div class="col-sm-3">
                        <h4><?= lang('menu') ?> </h4>
                        <ul>
                            <li>
                                <a href="<?= lang_url('user') ?>"><?= lang('users_home') ?></a>
                            </li> 
                            <li>
                                <a href="<?= lang_url('user/edit') ?>"><?= lang('edit_user_footer') ?></a>
                            </li> 
                            <li>
                                <a href="<?= base_url('user/logout') ?>"><?= lang('logout') ?></a>
                            </li> 
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h4><?= lang('support') ?></h4>
                        <ul>
                            <li><a href="<?= lang_url('contactus') ?>"><?= lang('write_us') ?></a></li>
                            <li><?= lang('or_call_us') . ' ' . $_sitePhone ?> </li>
                        </ul>
                    </div> 
                    <div class="col-sm-3">
                        <h4><?= lang('payment_methods') ?></h4>
                        <ul>
                            <li>
                                <i class="fa fa-2x fa-cc-paypal" aria-hidden="true"></i>
                                <i class="fa fa-2x fa-cc-visa" aria-hidden="true"></i> 
                            </li>
                            <li><span><?= lang('payment_on_spot') ?></span></li>
                        </ul>
                    </div>
                    <div class="col-sm-3">
                        <h4><?= lang('social_media') ?></h4>
                        <ul class="f-social">
                            <li>
                                <a href="<?= $_facebook ?>" target="_blank"><i class="fa fa-facebook"></i></a>
                                <a href="<?= $_instagram ?>" target="_blank"><i class="fa fa-instagram"></i></a>
                                <a href="<?= $_youtube ?>" target="_blank"><i class="fa fa-youtube"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="bottom-inner">
            <div class="container">
                <span>The Colossus © 2017</span>
            </div>
        </div>
    </div>
</div> 
<script src="<?= base_url('assets/bootstrap/js/bootstrap.min.js') ?>"></script>
<script src="<?= base_url('assets/user/js/general.js') ?>"></script>
<script src="<?= base_url('assets/public/js/placeholders.min.js') ?>"></script>
</div>
</div>
</body>
</html>