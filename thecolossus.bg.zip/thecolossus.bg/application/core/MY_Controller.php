<?php

class MY_Controller extends HEAD_Controller
{

    public function __construct()
    {
        parent::__construct();
    }

    public function render($view, $head, $data = null)
    {
        $this->getLanguages();
        $this->load->view('parts/header', $head);
        $this->load->view($view, $data);
        $this->load->view('parts/footer');
    }

    private function getLanguages()
    {
        $array = array();
        $languages = $this->PublicModel->getLanguages();
        foreach ($languages as $key => $language) {
            if ($language['abbr'] == MY_LANGUAGE_ABBR) {
                $array['my_lang_flag'] = $language['flag'];
                unset($languages[$key]);
            }
        }
        $array['languages'] = $languages;
        $this->load->vars($array);
    }

    public function setUserLogin($email)
    {
        $userInfo = $this->PublicModel->getUserInfoFromEmail($email);
        if (!empty($userInfo)) {
            $_SESSION['user_login'] = $userInfo;
            redirect(lang_url('user'));
        } else {
            log_message('error', 'Cant set user login for email: ' . $email);
            redirect(base_url());
        }
    }

}
