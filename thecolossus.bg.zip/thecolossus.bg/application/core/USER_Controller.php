<?php

class USER_Controller extends HEAD_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->loginCheck();
        $this->load->model('UsersModel');
    }

    public function render($view, $head, $data = null)
    {
        $head['events'] = $this->UsersModel->getCommingEvents();
        $head['allmyteams'] = $this->UsersModel->getAllMyTeams($_SESSION['user_login']['id']);
        $this->load->view('parts/header', $head);
        $this->load->view($view, $data);
        $this->load->view('parts/footer');
    }

    private function loginCheck()
    {
        if (!isset($_SESSION['user_login'])) {
            redirect(base_url());
        }
    }

}
