<?php

class HEAD_Controller extends MX_Controller
{

    public function __construct()
    {
        parent::__construct();
        /*
         * Block loading other pages if using subdomain
         * Subdomain are only for team preview page
         */
        if (count(explode('.', $_SERVER['HTTP_HOST'])) > 2 && uri_string() != null) {
            redirect(base_url());
        }
        $this->loadValueStores();
        $this->loadTexts();
    }

    private function loadValueStores()
    {
        $vars = array();
        $valueStores = $this->PublicModel->getValueStores();
        foreach ($valueStores as $valueStore) {
            $vars[$valueStore['v_key']] = $valueStore['value'];
        }
        $this->load->vars($vars);
    }

    /*
     * They are not so many.. 
     * I will load all of bunch
     */

    private function loadTexts()
    {
        $vars = array();
        $arrayTexts = $this->PublicModel->getTexts();
        foreach ($arrayTexts as $text) {
            $vars[$text['my_key']] = $text['text'];
        }
        $this->load->vars($vars);
    }

}
