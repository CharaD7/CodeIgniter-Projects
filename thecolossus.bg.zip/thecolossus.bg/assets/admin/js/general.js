var CURRENT_URL = window.location.href.split('#')[0].split('?')[0];
$(document).ready(function () {
// Mine Menu Nested Lists Toogle
    $('.side-menu a.category').click(function () {
        $(this).next('.child_menu').slideToggle("slow");
    });
// Toggle Menu for XS devices 
    $('#menu_toggle').on('click', function () {
        if ($('body').hasClass('nav-md')) {
            $('#sidebar-menu').find('li.active ul').hide();
            $('#sidebar-menu').find('li.active').addClass('active-sm').removeClass('active');
            $('.site_title img').addClass('active-sm');
        } else {
            $('#sidebar-menu').find('li.active-sm ul').show();
            $('#sidebar-menu').find('li.active-sm').addClass('active').removeClass('active-sm');
            $('.site_title img').removeClass('active-sm');
        }
        $('body').toggleClass('nav-md nav-sm');
    });
    $('.compose-open').click(function () {
        var data = $(this).data('reply-to');
        if (typeof data != 'undefined') {
            $('[name="to_email"]').val(data);
        }
        $('.compose').show();
    });
    $('.compose-close').click(function () {
        $('.compose').hide();
    });

    //right col height
    $('.right_col').css('min-height', $(window).height());
    var bodyHeight = $('body').outerHeight(),
            footerHeight = $('body').hasClass('footer_fixed') ? -10 : $('footer').height(),
            leftColHeight = $('.left_col').eq(1).height() + $('.sidebar-footer').height(),
            contentHeight = bodyHeight < leftColHeight ? leftColHeight : bodyHeight;
    contentHeight -= $('.nav_menu').height() + footerHeight;
    $('.right_col').css('min-height', contentHeight);

    // check active menu
    $('#sidebar-menu').find('a[href="' + CURRENT_URL + '"]').parent('li').addClass('current-page');
    $('#sidebar-menu').find('a').filter(function () {
        return this.href == CURRENT_URL;
    }).parent('li').addClass('current-page').parents('ul').slideDown(function () {
    }).parent().addClass('active');
});
function printEmail()
{
    var printContents = document.getElementById('theEmail').innerHTML;
    var originalContents = document.body.innerHTML;
    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
}
$(".confirm-delete").click(function (e) {
    e.preventDefault();
    var lHref = $(this).attr('href');
    bootbox.confirm({
        message: "Are you sure want to delete?",
        buttons: {
            confirm: {
                label: 'Yes',
                className: 'btn-success'
            },
            cancel: {
                label: 'No',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if (result) {
                window.location.href = lHref;
            }
        }
    });
});